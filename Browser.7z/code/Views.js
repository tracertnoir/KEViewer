/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.uk)throw new Error("The unit file 'Views.js' included twice!");EmWiApp.
uk=(function(){var B=EmWiApp;var C={};
var W=[0,0];var Ap="\uFEFF";var B_=[0,0,0,0];
C.AB={BW:0xFFFFFFFF,BX:0xFFFFFFFF,BZ:0xFFFFFFFF,BY:0xFFFFFFFF,Bs:function(Am,aClip
,aOffset,At,aBlend){var A;aBlend=aBlend&&((this.F&0x2)===0x2);At=At+1;if(At<256){
var BF=this.BY;var BG=this.BZ;var BD=this.BW;var BE=this.BX;BF=(BF&0x00FFFFFF)|((((
At*((BF>>24)&0xFF))>>8)&0xFF)<<24);BG=(BG&0x00FFFFFF)|((((At*((BG>>24)&0xFF))>>8
)&0xFF)<<24);BD=(BD&0x00FFFFFF)|((((At*((BD>>24)&0xFF))>>8)&0xFF)<<24);BE=(BE&0x00FFFFFF
)|((((At*((BE>>24)&0xFF))>>8)&0xFF)<<24);Am.D$(aClip,B.tz(this.K,aOffset),BF,BG,
BE,BD,aBlend);}else Am.D$(aClip,B.tz(this.K,aOffset),this.BY,this.BZ,this.BX,this.
BW,aBlend);},CW:function(D){var A;if((((D===this.BY)&&(D===this.BZ))&&(D===this.
BW))&&(D===this.BX))return;this.BY=D;this.BZ=D;this.BW=D;this.BX=D;if(!!this.J&&((
this.F&0x1)===0x1))this.J.AE(this.K);},_Init:function(aArg){B.Core.AI._Init.call(
this,aArg);this.__proto__=C.AB;},_className:"Views::Rectangle"};C.Text={Az:null,
B2:null,Ad:B.hm,String:B.hm,A0:null,Bf:B.qx,DB:0,Cy:0,BW:0xFFFFFFFF,BX:0xFFFFFFFF
,BZ:0xFFFFFFFF,BY:0xFFFFFFFF,C4:0,DD:B.qx,De:0x12,Eg:255,C3:0,Ek:false,EP:false,
EU:false,GL:false,Be:false,Bs:function(Am,aClip,aOffset,At,aBlend){var A;if((this.
Ad===B.hm)||!this.Az)return;var Z=this.De;var orient=this.C3;var font=this.Az;var
Ar=B.tz(this.K,aOffset);var BF=this.BY;var BG=this.BZ;var BE=this.BX;var BD=this.
BW;var BK=(((At+1)*this.Eg)>>8)+1;var Bz=this.Ad.charCodeAt(0)||0;var O=B.tz(this.
FL(),aOffset);var A2=[Ar[0]-O[0],(Ar[1]-O[1])-font.Ascent];if(Bz<1)return;if(BK<
256){BF=(BF&0x00FFFFFF)|((((((BF>>24)&0xFF)*BK)>>8)&0xFF)<<24);BG=(BG&0x00FFFFFF
)|((((((BG>>24)&0xFF)*BK)>>8)&0xFF)<<24);BE=(BE&0x00FFFFFF)|((((((BE>>24)&0xFF)*
BK)>>8)&0xFF)<<24);BD=(BD&0x00FFFFFF)|((((((BD>>24)&0xFF)*BK)>>8)&0xFF)<<24);}if(((
Z&0x80)===0x80)){if(this.EV())Z=(Z&~0x80)|0x4;else Z=(Z&~0x80)|0x1;}if(((Bz===1)&&
!((Z&0x40)===0x40))&&!orient){Am.FJ(aClip,font,this.Ad,2,(this.Ad.charCodeAt(1)||
0)-1,Ar,A2,0,orient,BF,BG,BE,BD,true);return;}var leading=font.Leading;if(this.Cy>
0)leading=(this.Cy-font.Ascent)-font.Descent;var FC=(font.Ascent+font.Descent)+leading;
var En=aClip[1]-O[1];var Eo=aClip[3]-O[1];var DM=O[2]-O[0];var Bq=0;var H=1;var AQ=
this.Ad.charCodeAt(H)||0;if(orient===1){A2=[O[3]-Ar[3],(Ar[0]-O[0])-font.Ascent];
En=aClip[0]-O[0];Eo=aClip[2]-O[0];DM=O[3]-O[1];}else if(orient===2){A2=[O[2]-Ar[
2],(O[3]-Ar[3])-font.Ascent];En=O[3]-aClip[3];Eo=O[3]-aClip[1];}else if(orient===
3){A2=[Ar[1]-O[1],(O[2]-Ar[2])-font.Ascent];En=O[2]-aClip[2];Eo=O[2]-aClip[0];DM=
O[3]-O[1];}while(((Bq+FC)<En)&&(AQ>0)){H=H+AQ;Bq=Bq+FC;AQ=this.Ad.charCodeAt(H)||
0;}while((Bq<Eo)&&(AQ>0)){var CN=B.tw(A2,[0,Bq]);var GB=0;var Ey=false;if(((((Z&
0x40)===0x40)&&((this.Ad.charCodeAt((H+AQ)-1)||0)!==0x0A))&&((this.Ad.charCodeAt(
H+1)||0)!==0x0A))&&((this.Ad.charCodeAt(H+AQ)||0)!==0x00))Ey=true;if(Ey&&!!(Z&0x6
)){var GA=H+AQ;var Gq=this.Ad.indexOf(String.fromCharCode(0x20),H+1);var Gr=this.
Ad.indexOf(String.fromCharCode(0xA0),H+1);if(((Gq<0)||(Gq>=GA))&&((Gr<0)||(Gr>=GA
)))Ey=false;}if(Ey)GB=DM;else if(((Z&0x4)===0x4))CN=[(CN[0]-DM)+font.Dk(this.Ad,
H+1,AQ-1),CN[1]];else if(((Z&0x2)===0x2))CN=[(CN[0]-((DM/2)|0))+((font.Dk(this.Ad
,H+1,AQ-1)/2)|0),CN[1]];Am.FJ(aClip,font,this.Ad,H+1,AQ-1,Ar,CN,GB,orient,BF,BG,
BE,BD,true);H=H+AQ;Bq=Bq+FC;AQ=this.Ad.charCodeAt(H)||0;}},Al:function(D){var A;
if(B.tm(D,this.K))return;var FA=false;if(!this.C3||(this.C3===2))FA=((A=this.K)[
2]-A[0])!==(D[2]-D[0]);else FA=((A=this.K)[3]-A[1])!==(D[3]-D[1]);if((((FA&&!this.
C4)&&this.Ek)&&this.Be)&&!((this.F&0x2000)===0x2000)){this.Ad=B.hm;this.Be=false;
B.lq([this,this.DZ],this);}if(((this.EU&&this.Be)&&!B.tl([(A=this.K)[2]-A[0],A[3
]-A[1]],[D[2]-D[0],D[3]-D[1]]))&&!((this.F&0x2000)===0x2000)){this.Ad=B.hm;this.
Be=false;B.lq([this,this.DZ],this);}B.Core.AI.Al.call(this,D);B.lq([this,this.Fx
],this);},Br:function(){if(!!this.A0){this.Fl(this.A0);this.A0=null;}},Fl:function(
aBidi){if(!aBidi)return;B.ng(aBidi);},HI:function(aSize){var bidi=null;bidi=B.qk(
aSize);return bidi;},Fx:function(Dc){B.lq(this.B2,this);},DZ:function(Dc){B.lq([
this,this.EF],this);},EF:function(Dc){var A;if(this.Be)return;var orient=this.C3;
var width=(A=this.K)[2]-A[0];var height=(A=this.K)[3]-A[1];var Bc=-1;if((orient===
1)||(orient===3)){width=height;height=(A=this.K)[2]-A[0];}if(this.Ek){if(this.C4>
0)Bc=this.C4;else if(!this.EP)Bc=width-(this.DB*2);else Bc=width;if(Bc<0)Bc=1;}if(
!!this.A0){this.Fl(this.A0);this.A0=null;}this.Be=true;if((this.String!==B.hm)&&
!!this.Az){var length=this.String.length;if(this.GL)this.A0=this.HI(length);this.
Ad=this.Az.G2(this.String,0,Bc,length,this.A0);if(!!this.A0&&!this.GP()){this.Fl(
this.A0);this.A0=null;}}else this.Ad=B.hm;this.Bf=W;if(((this.EU&&(this.Ad!==B.hm
))&&!this.EP)&&!!this.Az){var Z=this.De;var font=this.Az;var leading=font.Leading;
var Ac=this.Ad;var EI=this.EV();if(((Z&0x80)===0x80)){if(EI)Z=(Z&~0x80)|0x4;else
Z=(Z&~0x80)|0x1;}if(this.Cy>0)leading=(this.Cy-font.Ascent)-font.Descent;var D2=(
font.Ascent+font.Descent)+leading;var Bz=Ac.charCodeAt(0)||0;var Cj=((height+leading
)/D2)|0;var Fg=false;var Em=false;if(Cj<=0)Cj=1;if(Bz>Cj){var Bo=0;var D3=0;var EH=
Bz-1;var Av=0;var AG=Ac.length;var tmp=B.hm;if(((Z&0x20)===0x20))D3=Bz-Cj;else if(((
Z&0x10)===0x10)){D3=((Bz-Cj)/2)|0;EH=(D3+Cj)-1;}else EH=Cj-1;Fg=D3>0;Em=EH<(Bz-1
);for(Av=1;Bo<D3;Bo=Bo+1)Av=Av+(Ac.charCodeAt(Av)||0);if(Em)for(AG=Av;Bo<EH;Bo=Bo+
1)AG=AG+(Ac.charCodeAt(AG)||0);if(Fg){var AN=Ac.charCodeAt(Av)||0;tmp=(Ap+B.t9(Ac
,Av,AN))+Ap;tmp=B.t4(tmp,0,(AN+2)&0xFFFF);Av=Av+AN;if((tmp.charCodeAt(AN)||0)===
0x0A){tmp=B.t4(tmp,AN,0xFEFF);tmp=B.t4(tmp,AN+1,0x0A);}if((tmp.charCodeAt(2)||0)===
0x0A){tmp=B.t4(tmp,2,0xFEFF);tmp=B.t4(tmp,1,0x0A);}else tmp=B.t4(tmp,1,0xFEFF);}
tmp=tmp+B.t9(Ac,Av,AG-Av);if(Em&&(AG>=Av)){var AN=Ac.charCodeAt(AG)||0;var AU=(Ap+
B.t9(Ac,AG,AN))+Ap;AU=B.t4(AU,0,(AN+2)&0xFFFF);AU=B.t4(AU,1,0xFEFF);if((AU.charCodeAt(
AN)||0)===0x0A){AU=B.t4(AU,AN,0xFEFF);AU=B.t4(AU,AN+1,0x0A);}if((AU.charCodeAt(2
)||0)===0x0A){AU=B.t4(AU,2,0xFEFF);AU=B.t4(AU,1,0x0A);}else AU=B.t4(AU,1,0xFEFF);
tmp=tmp+AU;}Ac=String.fromCharCode(Cj&0xFFFF)+tmp;}var Bo=0;var Ex=1;var EC=width-(
this.DB*2);if(this.Ek&&(this.C4>0))EC=this.C4;Bz=Ac.charCodeAt(0)||0;for(;Bo<Bz;
Bo=Bo+1){var Co=Fg&&!Bo;var Cp=Em&&(Bo===(Bz-1));var Ba=false;var Bb=false;var Db=
EI;if((EI&&Co)&&!Cp){Co=false;Cp=true;}else if((EI&&Cp)&&!Co){Cp=false;Co=true;}
var D5=Ex+1;var AN=Ac.charCodeAt(Ex)||0;var Av=D5;var AG=(D5+AN)-2;var Fp=-1;var
Fq=-1;if(!this.Ek&&(font.Dk(Ac,D5,AN-1)>EC)){if(((Z&0x4)===0x4))Ba=true;else if(((
Z&0x2)===0x2)){Ba=true;Bb=true;}else Bb=true;}if((Ac.charCodeAt(Av)||0)===0x0A)Av=
Av+1;if((Ac.charCodeAt(AG)||0)===0x0A)AG=AG-1;while(Ba&&((Ac.charCodeAt(Av)||0)===
0xFEFF))Av=Av+1;while(Bb&&((Ac.charCodeAt(AG)||0)===0xFEFF))AG=AG-1;Ba=Ba&&!Cp;Bb=
Bb&&!Co;while((((Ba||Bb)||Co)||Cp)&&(Av<AG)){if((Ba&&(Db||!Bb))||Co){if(Fp>0)Ac=
B.t4(Ac,Fp,0xFEFF);Ac=B.t4(Ac,Av,0x2026);Fp=Av;Av=Av+1;Db=!Db;Co=false;if(font.Dk(
Ac,D5,AN-1)<=EC){Ba=false;Bb=false;}else Ba=Ba||!Bb;}if((Bb&&(!Db||!Ba))||Cp){if(
Fq>0)Ac=B.t4(Ac,Fq,0xFEFF);Ac=B.t4(Ac,AG,0x2026);Fq=AG;AG=AG-1;Db=!Db;Cp=false;if(
font.Dk(Ac,D5,AN-1)<=EC){Ba=false;Bb=false;}else Bb=Bb||!Ba;}}Ex=Ex+AN;}this.Bf=[
font.FM(Ac),((Ac.charCodeAt(0)||0)*D2)-leading];this.Ad=Ac;}if(this.EP&&(this.Ad
!==B.hm)){var BV=[this.DB,0];if((orient===1)||(orient===3)){BV=[BV[0],BV[0]];BV=[
0,BV[1]];}this.F=this.F|0x2000;this.Al(B.ty(B.th(this.FL(),BV),this.DD));this.F=
this.F&~0x2000;}if(!!this.J&&((this.F&0x1)===0x1))this.J.AE(this.K);B.lq([this,this.
Fx],this);},Gb:function(D){var A;if(D===this.De)return;this.De=D;if(!!this.J&&((
this.F&0x1)===0x1))this.J.AE(this.K);if(this.EU){this.Ad=B.hm;this.Be=false;B.lq([
this,this.DZ],this);}if(this.Be)B.lq([this,this.Fx],this);},Ee:function(D){if(D===
this.String)return;this.String=D;this.Ad=B.hm;this.Be=false;B.lq([this,this.DZ],
this);},Gc:function(D){if(D===this.Az)return;this.Az=D;this.Ad=B.hm;this.Be=false;
B.lq([this,this.DZ],this);},CW:function(D){var A;if((((D===this.BY)&&(D===this.BZ
))&&(D===this.BW))&&(D===this.BX))return;this.BY=D;this.BZ=D;this.BW=D;this.BX=D;
if(!!this.J&&((this.F&0x1)===0x1))this.J.AE(this.K);},EV:function(){if(!this.Be)
this.EF(this);if(!this.A0)return false;var result=false;var bidi=this.A0;result=
B.qj(bidi);return result;},GP:function(){if(!this.Be)this.EF(this);if(!this.A0)return false;
var result=false;var bidi=this.A0;result=B.sD(bidi);return result;},FL:function(
){var A;if((this.String===B.hm)||!this.Az)return B_;if(!this.Be)this.EF(this);if(
this.Ad===B.hm)return B_;var leading=this.Az.Leading;var D2=(this.Az.Ascent+this.
Az.Descent)+this.Az.Leading;if(this.Cy>0){leading=(this.Cy-this.Az.Ascent)-this.
Az.Descent;D2=this.Cy;}if(B.tl(this.Bf,W))this.Bf=[this.Az.FM(this.Ad),this.Bf[1
]];this.Bf=[this.Bf[0],((this.Ad.charCodeAt(0)||0)*D2)-leading];var Z=this.De;var
orient=this.C3;var Ae=this.K;var BV=this.DB;var width=Ae[2]-Ae[0];var height=Ae[
3]-Ae[1];if((orient===1)||(orient===3)){width=height;height=Ae[2]-Ae[0];}var Ar=[
BV,0,width-BV,height];var S=[].concat(Ar.slice(0,2),B.tx(Ar.slice(0,2),this.Bf));
if(((Z&0x80)===0x80)){if(this.EV())Z=(Z&~0x80)|0x4;else Z=(Z&~0x80)|0x1;}if(((Z&
0x40)===0x40)){var Bc=this.C4;if(Bc<=0)Bc=width-(this.DB*2);if(Bc<0)Bc=0;if(Bc>(
S[2]-S[0]))S=B.tZ(S,Bc);}if((S[2]-S[0])!==(Ar[2]-Ar[0])){if(((Z&0x4)===0x4))S=B.
t0(S,Ar[2]-(S[2]-S[0]));else if(((Z&0x2)===0x2))S=B.t0(S,(Ar[0]+(((Ar[2]-Ar[0])/
2)|0))-(((S[2]-S[0])/2)|0));}if((S[3]-S[1])!==(Ar[3]-Ar[1])){if(((Z&0x20)===0x20
))S=B.t2(S,Ar[3]-(S[3]-S[1]));else if(((Z&0x10)===0x10))S=B.t2(S,(Ar[1]+(((Ar[3]-
Ar[1])/2)|0))-(((S[3]-S[1])/2)|0));}if(!orient)S=B.tz(S,Ae.slice(0,2));else if(orient===
1){var Cm=[Ae[0]+S[1],Ae[3]-S[2]];S=[].concat(Cm,B.tx(Cm,[this.Bf[1],this.Bf[0]]
));}else if(orient===2){var Cm=[Ae[2]-S[2],Ae[3]-S[3]];S=[].concat(Cm,B.tx(Cm,this.
Bf));}else if(orient===3){var Cm=[Ae[2]-S[3],Ae[1]+S[0]];S=[].concat(Cm,B.tx(Cm,[
this.Bf[1],this.Bf[0]]));}return B.tz(S,this.DD);},_Init:function(aArg){B.Core.AI.
_Init.call(this,aArg);this.__proto__=C.Text;},_Done:function(){this.Br();this.__proto__=
B.Core.AI;B.Core.AI._Done.call(this);},_Mark:function(E){var A;B.Core.AI._Mark.call(
this,E);if((A=this.Az)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.B2)&&((A=A[
0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Views::Text"};C.ID={HW:0x1,HU:0x2
,HX:0x4,H4:0x8,H3:0x10,H2:0x20,HV:0x40,HT:0x80};C.C3={In:0,IA:1,Iy:2,Iz:3};
C._Init=function(){C.AB.__proto__=B.Core.AI;C.Text.__proto__=B.Core.AI;};C.Aw=function(
E){};return C;})();

/* Embedded Wizard */