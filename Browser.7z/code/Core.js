/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Core)throw new Error("The unit file 'Core.js' included twice!");EmWiApp.
Core=(function(){var B=EmWiApp;var C={};
var W=[0,0];var Ap=[0,0,0,0];var B_="The view does not belong to this group";var DG=
"No view to add";var DH="View already in a group";var DI="Recursive invalidate during active update cycle.";
var E7="The KeyPressHandler is embedded within an object not being derived "+"from Core::Group.";
C.Bt={Ay:null,AA:null,J:null,AD:null,F:0x103,DE:0,Cu:0x14,Ew:function(T,Gl){},E1:
function(D){var A;var HL=D^this.Cu;if(!HL)return;this.Cu=D;if(!!this.AD&&!((this.
F&0x400)===0x400)){this.J.F=this.J.F|0x5000;B.lq([A=this.J,A.BB],this);this.J.AE([
0,0,(A=this.J.K)[2]-A[0],A[3]-A[1]]);}if(!!this.AD&&((this.F&0x400)===0x400)){this.
AD.Da.F=this.AD.Da.F|0x1000;this.J.F=this.J.F|0x4000;B.lq([A=this.J,A.BB],this);
}},Bs:function(Am,aClip,aOffset,At,aBlend){},AH:function(P){return null;},Cs:function(
X,I,A_,E8,Fb){return null;},EO:function(T,CC){return W;},FQ:function(aOffset,Gk){
},GetExtent:function(){return Ap;},AO:function(BQ,CB){var A;if(((this.F&0x200)===
0x200))BQ=BQ&~0x400;var Fs=(this.F&~CB)|BQ;var Cd=Fs^this.F;this.F=Fs;if(!!this.
J&&!!(Cd&0x14)){var Gt=((this.F&0x14)===0x14);if(Gt&&!this.J.Bg)this.J.Dy(this);
if(!Gt&&(this.J.Bg===this))this.J.Dy(this.J.GN(this,0x14));}if(!!this.J&&!!(Cd&0x403
))this.J.AE(this.GetExtent());if(((!!this.AD&&!!this.J)&&((Fs&0x400)===0x400))&&((
Cd&0x1)===0x1)){this.F=this.F|0x800;this.J.F=this.J.F|0x4000;B.lq([A=this.J,A.BB
],this);}if(!!this.J&&((Cd&0x400)===0x400)){this.AD=null;this.F=this.F|0x800;this.
J.F=this.J.F|0x4000;B.lq([A=this.J,A.BB],this);}},_Init:function(aArg){this.__proto__=
C.Bt;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){}
,_Mark:function(E){var A;if((A=this.Ay)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.AA)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.J)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.AD)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A.
_cycle!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::View"
};C.AI={K:B.qy,Ew:function(T,Gl){var AF=B._NewObject(C.FO,0);AF.Cg=this.K;AF.Ae=
T;AF.Da=Gl;this.AD=AF;},EO:function(T,CC){var A;var Bn=this.Cu;var AF=this.AD;var
Ag=AF.Cg[0];var Ah=AF.Cg[1];var Aa=AF.Cg[2];var Ab=AF.Cg[3];var Cf=[T[2]-T[0],T[
3]-T[1]];var AX=Aa-Ag;var AW=Ab-Ah;if(!CC){var Dd=[(A=AF.Ae)[2]-A[0],A[3]-A[1]];
Ag=Ag-AF.Ae[0];Ah=Ah-AF.Ae[1];if(Dd[0]!==Cf[0]){var CE=((Bn&0x4)===0x4);var CF=((
Bn&0x8)===0x8);var D0=((Bn&0x1)===0x1);if(!CE&&(D0||!CF))Ag=((Ag*Cf[0])/Dd[0])|0;
if(!CF&&(D0||!CE)){Aa=Aa-AF.Ae[0];Aa=((Aa*Cf[0])/Dd[0])|0;Aa=Aa-Cf[0];}else Aa=Aa-
AF.Ae[2];Ag=Ag+T[0];Aa=Aa+T[2];if(!D0){if(CE&&!CF)Aa=Ag+AX;else if(!CE&&CF)Ag=Aa-
AX;else{Ag=Ag+((((Aa-Ag)-AX)/2)|0);Aa=Ag+AX;}}}else{Aa=Aa-AF.Ae[2];Ag=Ag+T[0];Aa=
Aa+T[2];}if(Dd[1]!==Cf[1]){var CG=((Bn&0x10)===0x10);var CD=((Bn&0x20)===0x20);var
D1=((Bn&0x2)===0x2);if(!CG&&(D1||!CD))Ah=((Ah*Cf[1])/Dd[1])|0;if(!CD&&(D1||!CG)){
Ab=Ab-AF.Ae[1];Ab=((Ab*Cf[1])/Dd[1])|0;Ab=Ab-Cf[1];}else Ab=Ab-AF.Ae[3];Ah=Ah+T[
1];Ab=Ab+T[3];if(!D1){if(CG&&!CD)Ab=Ah+AW;else if(!CG&&CD)Ah=Ab-AW;else{Ah=Ah+((((
Ab-Ah)-AW)/2)|0);Ab=Ah+AW;}}}else{Ab=Ab-AF.Ae[3];Ah=Ah+T[1];Ab=Ab+T[3];}}else{switch(
CC){case 3:{Ag=T[0];Aa=Ag+AX;}break;case 4:{Aa=T[2];Ag=Aa-AX;}break;case 1:{Ah=T[
1];Ab=Ah+AW;}break;case 2:{Ab=T[3];Ah=Ab-AW;}break;default:;}if((CC===3)||(CC===
4)){var CG=((Bn&0x10)===0x10);var CD=((Bn&0x20)===0x20);var D1=((Bn&0x2)===0x2);
if(D1){Ah=T[1];Ab=T[3];}else if(CG&&!CD){Ah=T[1];Ab=Ah+AW;}else if(CD&&!CG){Ab=T[
3];Ah=Ab-AW;}else{Ah=T[1]+((((T[3]-T[1])-AW)/2)|0);Ab=Ah+AW;}}if((CC===1)||(CC===
2)){var CE=((Bn&0x4)===0x4);var CF=((Bn&0x8)===0x8);var D0=((Bn&0x1)===0x1);if(D0
){Ag=T[0];Aa=T[2];}else if(CE&&!CF){Ag=T[0];Aa=Ag+AX;}else if(CF&&!CE){Aa=T[2];Ag=
Aa-AX;}else{Ag=T[0]+((((T[2]-T[0])-AX)/2)|0);Aa=Ag+AX;}}}AF.isEmpty=(Ag>=Aa)||(Ah>=
Ab);if(((this.F&0x100)===0x100)){this.K=[Ag,Ah,Aa,Ab];}else{this.Al([Ag,Ah,Aa,Ab
]);this.AD=AF;}return[Aa-Ag,Ab-Ah];},FQ:function(aOffset,Gk){if(Gk)this.K=B.tz(this.
K,aOffset);else this.Al(B.tz(this.K,aOffset));},GetExtent:function(){return this.
K;},Al:function(D){var A;if(B.tm(D,this.K))return;if(!!this.J&&((this.F&0x1)===0x1
))this.J.AE(this.K);this.AD=null;this.K=D;if(!!this.J&&((this.F&0x1)===0x1))this.
J.AE(this.K);if((!!this.J&&((this.F&0x400)===0x400))&&!((this.J.F&0x2000)===0x2000
)){this.F=this.F|0x800;this.J.F=this.J.F|0x4000;B.lq([A=this.J,A.BB],this);}},_Init:
function(aArg){C.Bt._Init.call(this,aArg);this.__proto__=C.AI;},_className:"Core::RectView"
};C.U={Bx:null,A1:null,Ez:null,A6:null,Ce:null,CL:null,Bg:null,Eg:255,Bs:function(
Am,aClip,aOffset,At,aBlend){var A;At=((At+1)*this.Eg)>>8;aBlend=aBlend&&((this.F&
0x2)===0x2);if(!this.A6)this.HM(Am,aClip,B.tx(aOffset,this.K.slice(0,2)),At,aBlend
);else{var AQ=255|(255<<8)|(255<<16)|((At&0xFF)<<24);this.A6.Update();Am.GF(aClip
,this.A6,0,B.tz(this.K,aOffset),W,AQ,AQ,AQ,AQ,aBlend);}},Cs:function(X,I,A_,E8,Fb
){var A;var G=this.A1;var CM=null;var O=Ap;var Aj=null;var Fr=!!this.CL&&(!!this.
CL.Fh||!!this.CL.Bx);if(((A=B.il(X,this.K))[0]>=A[2])||(A[1]>=A[3]))return null;
X=B.ty(X,this.K.slice(0,2));while(!!G){if(((G.F&0x400)===0x400)&&!Aj){Aj=G.AA;while(
!!Aj&&!((Aj.F&0x200)===0x200))Aj=Aj.AA;if(!!Aj)O=B.il(X,Aj.GetExtent());else O=Ap;
}if(Aj===G){Aj=null;O=Ap;}if((((((G.F&0x8)===0x8)&&((G.F&0x10)===0x10))&&!((G.F&
0x40000)===0x40000))&&!((G.F&0x20000)===0x20000))&&(!((G.F&0x10000)===0x10000)||((
this.Ce.AV===G)&&!Fr))){var Cg=G.GetExtent();var Es=E8;var CK=null;if(Es===G)Es=
null;if(((G.F&0x400)===0x400)){if(!(((A=B.il(Cg,O))[0]>=A[2])||(A[1]>=A[3])))CK=
G.Cs(O,I,A_,Es,Fb);}else{if(!(((A=B.il(Cg,X))[0]>=A[2])||(A[1]>=A[3]))||(E8===G)
)CK=G.Cs(X,I,A_,Es,Fb);}G=G.AA;if(!!CK){if(!CM||((CK.D_<CM.D_)&&(CK.D_>=0)))CM=CK;
if(!CK.D_)G=null;}}else G=G.AA;}return CM;},AO:function(BQ,CB){var A;var HO=this.
F;C.AI.AO.call(this,BQ,CB);var Cd=this.F^HO;if(!!this.Bg&&((Cd&0x40)===0x40)){if(((
this.F&0x40)===0x40))this.Bg.AO(0x40,0x0);else this.Bg.AO(0x0,0x40);}if(!!this.Ce&&((
Cd&0x40)===0x40)){if(((this.F&0x40)===0x40)&&((this.Ce.AV.F&0x14)===0x14))this.Ce.
AV.AO(0x40,0x0);else this.Ce.AV.AO(0x0,0x40);}if(!!Cd){this.F=this.F|0x8000;B.lq([
this,this.BB],this);}},Al:function(D){var A;if(B.tm(D,this.K))return;var Cl=[(A=
this.K)[2]-A[0],A[3]-A[1]];var ED=[D[2]-D[0],D[3]-D[1]];var CP=!B.tl(Cl,ED);if(CP&&
!!this.A6){this.A6.E0(ED);B.qw(this,0);B.qw(this.A6,0);}C.AI.Al.call(this,D);if((
CP&&(Cl[0]>0))&&(Cl[1]>0)){var Ae=[].concat(W,Cl);var G=this.Bx;var DT=0x14;while(
!!G){if((!G.AD&&(G.Cu!==DT))&&!((G.F&0x400)===0x400))G.Ew(Ae,null);G=G.Ay;}}if(CP
){this.F=this.F|0x5000;B.lq([this,this.BB],this);}},Fy:function(P){var Gv=(C.KeyEvent.
isPrototypeOf(P)?P:null);var Bm=this.Ez;if(!Gv)return null;while(!!Bm&&(!Bm.CU||
!Bm.AH(Gv)))Bm=Bm.Ay;return Bm;},HM:function(Am,aClip,aOffset,At,aBlend){var A;var
G=this.Bx;var Gs=Ap;var Gy=true;while(!!G){if(((G.F&0x200)===0x200)){var Gx=(C.DA.
isPrototypeOf(G)?G:null);Gs=B.il(aClip,B.tz(Gx.K,aOffset));Gy=((Gx.F&0x1)===0x1);
}if(((G.F&0x1)===0x1)){if(((G.F&0x400)===0x400)){if(Gy){var O=B.il(B.tz(G.GetExtent(
),aOffset),Gs);if(!((O[0]>=O[2])||(O[1]>=O[3])))G.Bs(Am,O,aOffset,At,aBlend);}}else{
var O=B.il(B.tz(G.GetExtent(),aOffset),aClip);if(!((O[0]>=O[2])||(O[1]>=O[3])))G.
Bs(Am,O,aOffset,At,aBlend);}}G=G.Ay;}},HQ:function(){var A;var Fn=((this.F&0x1000
)===0x1000);var BS=[0,0,(A=this.K)[2]-A[0],A[3]-A[1]];var Bk=false;var By=Ap;var
Au=Ap;var Bl=W;var C9=0;var C_=0;var C8=0;var AR=0;var G=this.A1;var Aj=null;var
DT=0x14;var Ci=null;while(!!G){if(((G.F&0x800)===0x800)){Bk=true;G.F=G.F&~0x800;
}if(Bk&&((G.F&0x200)===0x200)){Bk=false;if(!!(C.DA.isPrototypeOf(G)?G:null).Ea)G.
F=G.F|0x1000;}G=G.AA;}Bk=false;G=this.Bx;if(Fn){this.F=this.F&~0x1000;Fn=!((BS[0
]>=BS[2])||(BS[1]>=BS[3]));}this.F=this.F|0x2000;while(!!G){if(!Ci&&(C8!==AR)){var
BC=G;var EG=0;var D4=By[2]-By[0];var DO=By[3]-By[1];var Ep=0;var CR=W;do{if(((BC.
F&0x200)===0x200))BC=null;else if(((BC.F&0x401)===0x401)){CR=[(A=BC.GetExtent())[
2]-A[0],A[3]-A[1]];if((AR===3)||(AR===4))D4=D4-CR[0];if((AR===1)||(AR===2))DO=DO-
CR[1];if(!Ci||((D4>=0)&&(DO>=0))){Ci=BC;BC=BC.Ay;if((AR===3)||(AR===4)){D4=D4-C9;
if(CR[1]>EG)EG=CR[1];}if((AR===1)||(AR===2)){DO=DO-C_;if(CR[0]>Ep)Ep=CR[0];}}else
BC=null;}else BC=BC.Ay;}while(!!BC);if(!Ci)Ci=Aj;Au=By;switch(C8){case 9:case 11:
Au=[].concat(Au.slice(0,3),Au[1]+EG);break;case 10:case 12:Au=B.t3(Au,Au[3]-EG);
break;case 5:case 7:Au=B.t1(Au,Au[0]+Ep);break;case 6:case 8:Au=[].concat(Au[2]-
Ep,Au.slice(1,4));break;default:;}}if(((G.F&0x400)===0x400)){if(!!G.AD&&(G.AD.Da
!==Aj))G.AD=null;if((!G.AD&&Bk)&&((G.Cu!==DT)||!!AR))G.Ew(Au,Aj);}if(!!G.AD){if(
Fn&&!((G.F&0x400)===0x400))G.EO(BS,0);if(Bk&&((G.F&0x400)===0x400)){var EK=G.EO(
B.tz(Au,Bl),AR);if(((G.F&0x1)===0x1)){var A2=W;switch(AR){case 3:A2=[EK[0]+C9,A2[
1]];break;case 4:A2=[-EK[0]-C9,A2[1]];break;case 1:A2=[A2[0],EK[1]+C_];break;case
2:A2=[A2[0],-EK[1]-C_];break;default:;}Bl=B.tx(Bl,A2);}}}if(((G.F&0x200)===0x200
)){if(Bk)B.lq(Aj.B2,Aj);Bk=((G.F&0x1000)===0x1000);Aj=(C.DA.isPrototypeOf(G)?G:null
);if(Bk){G.F=G.F&~0x1000;By=B.tz(Aj.K,Aj.DD);Au=By;Bl=W;C8=Aj.Ea;AR=C8;C9=Aj.Space+
Aj.G4;C_=Aj.Space+Aj.G6;Bk=!((By[0]>=By[2])||(By[1]>=By[3]));Ci=null;switch(C8){
case 9:case 10:AR=3;break;case 11:case 12:AR=4;break;case 5:case 6:AR=1;break;case
7:case 8:AR=2;break;default:;}}if(Bk){this.AE(Aj.K);}}if(G===Ci){switch(C8){case
9:case 11:Bl=[0,(Bl[1]+(Au[3]-Au[1]))+C_];break;case 10:case 12:Bl=[0,(Bl[1]-(Au[
3]-Au[1]))-C_];break;case 5:case 7:Bl=[(Bl[0]+(Au[2]-Au[0]))+C9,0];break;case 6:
case 8:Bl=[(Bl[0]-(Au[2]-Au[0]))-C9,0];break;default:;}Ci=null;}G=G.Ay;}if(Bk)B.
lq(Aj.B2,Aj);this.F=this.F&~0x2000;this.Eh([BS[2]-BS[0],BS[3]-BS[1]]);},BB:function(
Dc){var A;var HS=((this.F&0x1000)===0x1000);if(((this.F&0x4000)===0x4000)){this.
F=this.F&~0x4000;this.HQ();}if(((this.F&0x8000)===0x8000)||HS){this.F=this.F&~0x8000;
this.E6(this.F);}},Dy:function(D){var A;if(!!D&&(D.J!==this))throw new Error(B_);
if(!!D&&!((D.F&0x14)===0x14))D=null;if(!!D&&((D.F&0x10000)===0x10000))D=null;if(
D===this.Bg)return;if(!!this.Bg)this.Bg.AO(0x0,0x60);this.Bg=D;if(!!D){if(((this.
F&0x40)===0x40))D.AO(0x60,0x0);else D.AO(0x20,0x0);}},FP:function(Fa){var tmp=this;
while(!!tmp){Fa=B.tw(Fa,tmp.K.slice(0,2));tmp=tmp.J;}return Fa;},DispatchEvent:function(
P){var A;var G=this.Bg;var M=(C.U.isPrototypeOf(G)?G:null);var Q=null;var Fr=!!this.
CL&&(!!this.CL.Fh||!!this.CL.Bx);if(!!G&&((((G.F&0x10000)===0x10000)||((G.F&0x40000
)===0x40000))||((G.F&0x20000)===0x20000))){G=null;M=null;}if(!!this.Ce&&!Fr)Q=this.
Ce.AV.DispatchEvent(P);if(!Q&&!!M)Q=M.DispatchEvent(P);else if(!Q&&!!G)Q=G.AH(P);
if(!Q)Q=this.AH(P);if(!Q)Q=this.Fy(P);return Q;},BroadcastEventAtPosition:function(
P,Gm,AZ){var A;var G=this.A1;var Q=null;while(!!G&&!Q){if((!AZ||((A=AZ)&&((G.F&A
)===A)))&&B.qu(G.GetExtent(),Gm)){var M=(C.U.isPrototypeOf(G)?G:null);if(!!M)Q=M.
BroadcastEventAtPosition(P,B.tw(Gm,M.K.slice(0,2)),AZ);else Q=G.AH(P);}G=G.AA;}if(
!Q)Q=this.AH(P);return Q;},BroadcastEvent:function(P,AZ){var A;var G=this.A1;var
Q=null;while(!!G&&!Q){if(!AZ||((A=AZ)&&((G.F&A)===A))){var M=(C.U.isPrototypeOf(
G)?G:null);if(!!M)Q=M.BroadcastEvent(P,AZ);else Q=G.AH(P);}G=G.AA;}if(!Q)Q=this.
AH(P);if(!Q)Q=this.Fy(P);return Q;},Eh:function(aSize){},E6:function(Gn){},FN:function(
){this.F=this.F|0x8000;B.lq([this,this.BB],this);},AE:function(X){var A;var M=this;
while(!!M&&!((X[0]>=X[2])||(X[1]>=X[3]))){var CH=M.A6;if(!M.J&&(M!==this)){M.AE(
X);return;}if(!!CH){var Fm=false;var HN=CH.Bh;if(Fm)CH.Bh=[0,0,(A=M.K)[2]-A[0],A[
3]-A[1]];else CH.Bh=B.qR(CH.Bh,X);if(!B.tm(HN,CH.Bh)){B.qw(M,0);B.qw(CH,0);}}if(
!((M.F&0x1)===0x1))return;X=B.il(B.tz(X,M.K.slice(0,2)),M.K);M=M.J;}},AY:function(
aArg){this.FN();},GN:function(V,AZ){var A;if(!V||(V.J!==this))return null;var Ck=
V.Ay;var Cn=V.AA;var DX=0x10000;if(((AZ&0x10000)===0x10000))DX=0x0;while(!!Ck||!
!Cn){if((!!Ck&&(!AZ||((A=AZ)&&((Ck.F&A)===A))))&&(!DX||!((A=DX)&&((Ck.F&A)===A))
))return Ck;if((!!Cn&&(!AZ||((A=AZ)&&((Cn.F&A)===A))))&&(!DX||!((A=DX)&&((Cn.F&A
)===A))))return Cn;if(!!Ck)Ck=Ck.Ay;if(!!Cn)Cn=Cn.AA;}return null;},A7:function(
V,C6){var A;if(!V)throw new Error(DG);if(!!V.J)throw new Error(DH);var AP=null;var
EJ=V.DE;if(((C6<0)&&!!this.A1)&&(this.A1.DE>=EJ)){AP=this.A1;C6=C6+1;}while((((C6<
0)&&!!AP)&&!!AP.AA)&&(AP.AA.DE>=EJ)){AP=AP.AA;C6=C6+1;}if((!AP&&!!this.A1)&&(this.
A1.DE>EJ))AP=this.A1;while((!!AP&&!!AP.AA)&&(AP.AA.DE>EJ))AP=AP.AA;if(!AP){V.J=this;
V.AA=this.A1;if(!!this.A1)this.A1.Ay=V;if(!this.Bx)this.Bx=V;this.A1=V;}else{V.J=
this;V.AA=AP.AA;V.Ay=AP;AP.AA=V;if(!!V.AA)V.AA.Ay=V;else this.Bx=V;}if(((V.F&0x1
)===0x1))this.AE(V.GetExtent());if(((!this.Bg&&((V.F&0x4)===0x4))&&((V.F&0x10)===
0x10))&&!((V.F&0x10000)===0x10000))this.Dy(V);if(((V.F&0x401)===0x401)){V.F=V.F|
0x800;this.F=this.F|0x4000;B.lq([this,this.BB],this);}if(((V.F&0x200)===0x200)){
V.F=V.F|0x800;this.F=this.F|0x4000;B.lq([this,this.BB],this);}},_Init:function(aArg
){C.AI._Init.call(this,aArg);this.__proto__=C.U;this.F=0x1F;this.AY(aArg);},_Mark:
function(E){var A;C.AI._Mark.call(this,E);if((A=this.Bx)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.A1)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Ez)&&(A.
_cycle!=E))A._Mark(A._cycle=E);if((A=this.A6)&&(A._cycle!=E))A._Mark(A._cycle=E);
if((A=this.Ce)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.CL)&&(A._cycle!=E))
A._Mark(A._cycle=E);if((A=this.Bg)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:
"Core::Group"};C.Root={AT:null,BU:null,Bv:null,Ax:B.tA(10,null,null),C7:null,A9:
null,BR:null,D6:0,Fd:0,Y:0,AK:B.tA(10,0,null),Er:B.tA(10,B.qy,null),Bw:B.tA(10,0
,null),Cc:B.tA(10,B.qx,null),DQ:B.tA(10,0,null),CI:B.tA(10,B.qx,null),BH:B.tA(10
,B.qx,null),BI:B.tA(10,B.qx,null),Cb:B.tA(10,B.qx,null),CJ:0,Ev:0,Eu:0,EB:B.tA(3
,B.qy,null),Gw:0,AM:B.tA(4,0,null),As:B.tA(4,B.qy,null),An:0,D9:8,GH:250,Ch:0,BT:
0,Fo:true,EA:false,Bs:function(Am,aClip,aOffset,At,aBlend){var fullScreenUpdate=
false;fullScreenUpdate=B.jI;if(!fullScreenUpdate)Am.D$(aClip,B.tz(B.tz(aClip,aOffset
),this.K.slice(0,2)),0x00000000,0x00000000,0x00000000,0x00000000,false);C.U.Bs.call(
this,Am,aClip,aOffset,At,aBlend);},AO:function(BQ,CB){var A;C.U.AO.call(this,BQ,
CB);if(!this.J&&(((BQ&0x1)===0x1)||((CB&0x1)===0x1)))this.AE([0,0,(A=this.K)[2]-
A[0],A[3]-A[1]]);if(!this.J&&(((BQ&0x2)===0x2)||((CB&0x2)===0x2)))this.AE([0,0,(
A=this.K)[2]-A[0],A[3]-A[1]]);},Dy:function(D){if((D!==this.A9)||!D)C.U.Dy.call(
this,D);},DispatchEvent:function(P){if((this.Fd>0)&&!!(C.KeyEvent.isPrototypeOf(
P)?P:null))return null;if(!!P){P.Dp=!!this.Y;if(!!this.Y)P.A8=this.Y;}var Q=null;
if(!!this.A9){Q=this.A9.DispatchEvent(P);if(!!Q){this.Y=0;return Q;}}if(!!this.BU
){Q=this.BU.AV.DispatchEvent(P);if(!Q)Q=this.AH(P);if(!Q)Q=this.Fy(P);this.Y=0;return Q;
}Q=C.U.DispatchEvent.call(this,P);this.Y=0;return Q;},BroadcastEvent:function(P,
AZ){if(!!P){P.Dp=!!this.Y;if(!!this.Y)P.A8=this.Y;}var Q=C.U.BroadcastEvent.call(
this,P,AZ);this.Y=0;return Q;},AE:function(X){var A;if(this.D6>0)throw new Error(
DI);if(!!this.A6&&!this.J){if(((A=this.A6.Bh)[0]>=A[2])||(A[1]>=A[3])){B.qw(this
,0);B.qw(this.A6,0);}var Fm=false;if(Fm)this.A6.Bh=[0,0,(A=this.K)[2]-A[0],A[3]-
A[1]];else this.A6.Bh=B.qR(this.A6.Bh,X);}var fullScreenUpdate=false;fullScreenUpdate=
B.jI;if(fullScreenUpdate)X=[0,0,(A=this.K)[2]-A[0],A[3]-A[1]];if(!!this.J){C.U.AE.
call(this,X);return;}X=B.il(B.tz(X,this.K.slice(0,2)),this.K);if((X[0]>=X[2])||(
X[1]>=X[3]))return;var H;for(H=0;H<this.An;H=H+1)if(!(((A=B.il(this.As.Get(H),X)
)[0]>=A[2])||(A[1]>=A[3]))){this.As.Set(H,B.qR(this.As.Get(H),X));this.AM.Set(H,
B.s9(this.As.Get(H)));return;}if(this.An<3){this.As.Set(this.An,X);this.AM.Set(this.
An,B.s9(X));this.An=this.An+1;return;}var Af;var AS;var DU=0;var DV=0;var Gp=2147483647;
this.As.Set(this.An,X);this.AM.Set(this.An,B.s9(X));for(Af=0;Af<=this.An;Af=Af+1
)for(AS=Af+1;AS<=this.An;AS=AS+1){var EL=B.s9(B.qR(this.As.Get(Af),this.As.Get(AS
)));var Gz=((EL<<8)/(this.AM.Get(Af)+this.AM.Get(AS)))|0;if(Gz<Gp){Gp=Gz;DU=Af;DV=
AS;}}this.As.Set(DU,B.qR(this.As.Get(DU),this.As.Get(DV)));this.AM.Set(DU,B.s9(this.
As.Get(DU)));if(DV!==this.An){this.As.Set(DV,this.As.Get(this.An));this.AM.Set(DV
,this.AM.Get(this.An));}},HJ:function(){var AC=B._NewObject(C.ET,0);AC.Dp=!!this.
Y;if(!!this.Y)AC.A8=this.Y;return AC;},DP:function(){var AC=B._NewObject(C.ER,0);
AC.Dp=!!this.Y;if(!!this.Y)AC.A8=this.Y;return AC;},Eq:function(){var AC=B._NewObject(
C.ES,0);AC.Dp=!!this.Y;if(!!this.Y)AC.A8=this.Y;return AC;},HK:function(Dc){var H;
var CM=false;for(H=0;H<10;H=H+1)if(!!this.Ax.Get(H)){var AL=this.BI.Get(H);var M=
this.Ax.Get(H).J;while(!!M&&(M!==this)){AL=B.tw(AL,M.K.slice(0,2));M=M.J;}if(!M&&(
this.Ax.Get(H)!==this)){var tmp=this.Ax.Get(H);this.CJ=H;this.Ax.Set(H,null);tmp.
AH(this.DP().InitializeUp(H,this.CI.Get(H),this.Cc.Get(H),this.Bw.Get(H),this.AK.
Get(H)+1,this.BH.Get(H),false,this.BI.Get(H),this.Cb.Get(H)));if(tmp===this.Bv)this.
Bv=null;this.BroadcastEvent(this.Eq().InitializeUp(H,this.AK.Get(H)+1,false,tmp,
this.BI.Get(H)),0x18);}else{this.Bw.Set(H,(this.BR.A8-this.DQ.Get(H))|0);if(this.
Bw.Get(H)<10)this.Bw.Set(H,10);this.CJ=H;this.Ax.Get(H).AH(this.DP().InitializeHold(
H,AL,this.Cc.Get(H),this.Bw.Get(H),this.AK.Get(H)+1,this.BH.Get(H),this.BI.Get(H
),this.Cb.Get(H)));CM=true;}}if(!CM)this.BR.Ed(false);},GetFPS:function(){var ticksCount=
0;var Gu=0;ticksCount=((new Date).getTime()-B.qt)|0;if(!!this.Ev&&(ticksCount>this.
Ev))Gu=((this.Eu*1000)/((ticksCount-this.Ev)|0))|0;this.Eu=0;this.Ev=ticksCount;
return Gu;},Update:function(){var A;if(!this.C7){this.C7=B._NewObject(B.Graphics.
Canvas,0);this.C7.E0([(A=this.K)[2]-A[0],A[3]-A[1]]);}this.C7.Update();return this.
UpdateGE20(this.C7);},UpdateGE20:function(Am){if(!this.BeginUpdate())return Ap;var
BL=this.UpdateCanvas(Am,W);this.EndUpdate();return BL;},EndUpdate:function(){if(
this.An>0){this.Eu=this.Eu+1;this.An=0;}},UpdateCanvas:function(Am,aOffset){var A;
var BL=Ap;var HH=[].concat(aOffset,B.tx(Am.FrameSize,aOffset));var H;var Af=this.
An;this.D6=this.D6+1;for(H=0;(H<Af)&&(H<4);H=H+1){if(this.AM.Get(H)>0){this.Bs(Am
,B.ty(this.As.Get(H),aOffset),[-aOffset[0],-aOffset[1]],255,true);BL=B.qR(BL,B.il(
HH,this.As.Get(H)));}else Af=Af+1;}this.D6=this.D6-1;if(!((BL[0]>=BL[2])||(BL[1]>=
BL[3])))return B.ty(BL,aOffset);else return BL;},GetUpdateRegion:function(El){var
H;var Af=this.An;if(El<0)return Ap;for(H=0;(H<Af)&&(H<4);H=H+1){if(!this.AM.Get(
H)){Af=Af+1;El=El+1;}else if(H===El)return this.As.Get(H);}return Ap;},BeginUpdate:
function(){var HP=true;var fullScreenUpdate=false;var H;if((!HP&&!fullScreenUpdate
)&&(this.An>0)){var GC=B.tA(3,B.qy,null);var FD=this.An;for(H=0;H<FD;H=H+1)GC.Set(
H,this.As.Get(H));for(H=0;H<this.Gw;H=H+1)this.AE(this.EB.Get(H));for(H=0;H<FD;H=
H+1)this.EB.Set(H,GC.Get(H));this.Gw=FD;}var Af;var AS;for(Af=0;Af<(this.An-1);Af=
Af+1)if(this.AM.Get(Af)>0)for(AS=Af+1;AS<this.An;AS=AS+1)if(this.AM.Get(AS)>0){var
EL=B.s9(B.qR(this.As.Get(Af),this.As.Get(AS)));if(((EL-this.AM.Get(Af))-this.AM.
Get(AS))<0){this.As.Set(Af,B.qR(this.As.Get(Af),this.As.Get(AS)));this.AM.Set(Af
,EL);this.AM.Set(AS,0);}}for(H=this.An-1;H>=0;H=H-1)if(!this.AM.Get(H))this.An=this.
An-1;return this.An;},DoesNeedUpdate:function(){if(this.An>0)return true;return false;
},Initialize:function(aSize){this.Al([].concat(W,aSize));if(this.Fo)this.F=this.
F|0x60;else this.F=this.F|0x20;this.AE(this.K);return this;},SetRootFocus:function(
E_){if(E_===this.Fo)return false;this.Fo=E_;if(!E_){if(!!this.A9)this.A9.AO(0x0,
0x40);if(!!this.BU)this.BU.AV.AO(0x0,0x40);else this.AO(0x0,0x40);}else{if(!!this.
BU)this.BU.AV.AO(0x40,0x0);else this.AO(0x40,0x0);if(!!this.A9)this.A9.AO(0x40,0x0
);}return true;},SetUserInputTimestamp:function(HG){this.Y=HG;},DriveKeyboardHitting:
function(Ai,CA,A5){var A;var Fz=!!this.AT;if(!!this.AT&&((!A5||(this.Ch!==Ai))||(
this.BT!==CA))){var AC=null;var G=(C.Bt.isPrototypeOf(A=this.AT)?A:null);var Bm=(
C.Ec.isPrototypeOf(A=this.AT)?A:null);if(!!this.Ch)AC=B._NewObject(C.KeyEvent,0).
Initialize(this.Ch,false);if(this.BT!==0x00)AC=B._NewObject(C.KeyEvent,0).Initialize2(
this.BT,false);if(!!Bm)Bm.AH(AC);else if(!!G)G.AH(AC);this.Ch=0;this.BT=0x00;this.
AT=null;}if(!!this.AT){var AC=null;var G=(C.Bt.isPrototypeOf(A=this.AT)?A:null);
var Bm=(C.Ec.isPrototypeOf(A=this.AT)?A:null);if(!!Ai)AC=B._NewObject(C.KeyEvent
,0).Initialize(Ai,true);if(this.BT!==0x00)AC=B._NewObject(C.KeyEvent,0).Initialize2(
CA,true);if(!!Bm)Bm.AH(AC);else if(!!G)G.AH(AC);}if(this.EA&&((!A5||(this.Ch!==Ai
))||(this.BT!==CA))){this.Ch=0;this.BT=0x00;this.EA=false;}if((!this.AT&&A5)&&(this.
Fd>0)){this.Ch=Ai;this.BT=CA;this.EA=true;}if((!this.AT&&A5)&&!this.EA){if(!!Ai)
this.AT=this.DispatchEvent(B._NewObject(C.KeyEvent,0).Initialize(Ai,true));if(CA
!==0x00)this.AT=this.DispatchEvent(B._NewObject(C.KeyEvent,0).Initialize2(CA,true
));if(!(C.Ec.isPrototypeOf(A=this.AT)?A:null)&&!(C.Bt.isPrototypeOf(A=this.AT)?A:
null))this.AT=null;this.Ch=Ai;this.BT=CA;Fz=Fz||!!this.AT;}this.Y=0;return Fz;},
DriveCursorMovement:function(Aq){return this.DriveMultiTouchMovement(this.CJ,Aq);
},DriveMultiTouchMovement:function(I,Aq){if((I<0)||(I>9)){this.Y=0;return false;
}var DY=B.tw(Aq,this.BI.Get(I));this.BI.Set(I,Aq);if(!this.Ax.Get(I)||B.tl(DY,W)
){this.Y=0;return false;}var AL=Aq;var M=this.Ax.Get(I).J;while(!!M&&(M!==this)){
AL=B.tw(AL,M.K.slice(0,2));M=M.J;}if(!M&&(this.Ax.Get(I)!==this)){var tmp=this.Ax.
Get(I);this.CJ=I;this.Ax.Set(I,null);tmp.AH(this.DP().InitializeUp(I,this.CI.Get(
I),this.Cc.Get(I),this.Bw.Get(I),this.AK.Get(I)+1,this.BH.Get(I),false,this.BI.Get(
I),this.Cb.Get(I)));if(tmp===this.Bv)this.Bv=null;this.BroadcastEvent(this.Eq().
InitializeUp(I,this.AK.Get(I)+1,false,tmp,Aq),0x18);}else{this.CI.Set(I,AL);this.
CJ=I;this.Ax.Get(I).AH(this.HJ().Initialize(I,AL,this.Cc.Get(I),DY,this.Bw.Get(I
),this.AK.Get(I)+1,this.BH.Get(I),Aq,this.Cb.Get(I)));}this.Y=0;return true;},DriveCursorHitting:
function(A5,I,Aq){return this.DriveMultiTouchHitting(A5,I,Aq);},DriveMultiTouchHitting:
function(A5,I,Aq){var A;if((I<0)||(I>9)){this.Y=0;return false;}var ticksCount=this.
Y;var DR=[].concat([-this.D9,-this.D9],[this.D9+1,this.D9+1]);if(!ticksCount){ticksCount=((
new Date).getTime()-B.qt)|0;}var HR=this.Y;this.DriveMultiTouchMovement(I,Aq);Aq=
this.BI.Get(I);this.Y=HR;if(A5)this.Cb.Set(I,Aq);if((A5&&!this.Ax.Get(I))&&!this.
Fd){var BJ=null;var AL=Aq;if(B.qu(this.Er.Get(I),Aq)&&((ticksCount-this.DQ.Get(I
))<=(((A=this.GH)<0)?A+0x100000000:A)))this.AK.Set(I,this.AK.Get(I)+1);else this.
AK.Set(I,0);this.Er.Set(I,B.tz(DR,Aq));this.DQ.Set(I,ticksCount);if((!!this.A9&&
!!this.A9.J)&&((this.A9.F&0x18)===0x18)){var O=B.tz(DR,this.A9.J.FP(Aq));BJ=this.
A9.Cs(O,I,this.AK.Get(I)+1,null,0x0);}if(!BJ){if(!!this.Bv&&!!this.Bv.J){if(((this.
Bv.F&0x8)===0x8)&&((this.Bv.F&0x10)===0x10)){var O=B.tz(DR,this.Bv.J.FP(Aq));BJ=
this.Bv.Cs(O,I,this.AK.Get(I)+1,null,0x0);}}else if(!!this.BU)BJ=this.Cs(B.tz(DR
,Aq),I,this.AK.Get(I)+1,this.BU.AV,0x0);else BJ=this.Cs(B.tz(DR,Aq),I,this.AK.Get(
I)+1,null,0x0);}if(!!BJ){this.BroadcastEvent(this.Eq().InitializeDown(I,this.AK.
Get(I)+1,false,BJ.Bt,Aq),0x18);this.Ax.Set(I,BJ.Bt);this.BH.Set(I,BJ.EZ);}else{this.
Ax.Set(I,null);this.BH.Set(I,W);this.Y=0;return false;}var M=BJ.Bt.J;while(!!M&&(
M!==this)){AL=B.tw(AL,M.K.slice(0,2));M=M.J;}this.Cc.Set(I,AL);this.CI.Set(I,AL);
this.Bw.Set(I,0);this.BR.Ed(true);this.CJ=I;this.Ax.Get(I).AH(this.DP().InitializeDown(
I,AL,this.AK.Get(I)+1,this.BH.Get(I),false,Aq));this.Y=0;return true;}if(!A5&&!!
this.Ax.Get(I)){var AL=Aq;var M=this.Ax.Get(I).J;while(!!M&&(M!==this)){AL=B.tw(
AL,M.K.slice(0,2));M=M.J;}if(!M)AL=this.CI.Get(I);this.CJ=I;var tmp=this.Ax.Get(
I);this.Ax.Set(I,null);tmp.AH(this.DP().InitializeUp(I,AL,this.Cc.Get(I),this.Bw.
Get(I),this.AK.Get(I)+1,this.BH.Get(I),false,Aq,this.Cb.Get(I)));this.BroadcastEvent(
this.Eq().InitializeUp(I,this.AK.Get(I)+1,false,tmp,Aq),0x18);this.Y=0;return true;
}this.Y=0;return false;},_Init:function(aArg){C.U._Init.call(this,aArg);C.Timer.
_Init.call(this.BR={N:this},0);(this.Ax=[]).__proto__=C.Root.Ax;(this.AK=[]).__proto__=
C.Root.AK;(this.Er=[]).__proto__=C.Root.Er;(this.Bw=[]).__proto__=C.Root.Bw;(this.
Cc=[]).__proto__=C.Root.Cc;(this.DQ=[]).__proto__=C.Root.DQ;(this.CI=[]).__proto__=
C.Root.CI;(this.BH=[]).__proto__=C.Root.BH;(this.BI=[]).__proto__=C.Root.BI;(this.
Cb=[]).__proto__=C.Root.Cb;(this.EB=[]).__proto__=C.Root.EB;(this.AM=[]).__proto__=
C.Root.AM;(this.As=[]).__proto__=C.Root.As;this.__proto__=C.Root;this.F=0x7F;this.
BR.G0(50);this.BR.Ef=[this,this.HK];},_Done:function(){this.__proto__=C.U;this.BR.
_Done();C.U._Done.call(this);},_ReInit:function(){C.U._ReInit.call(this);this.BR.
_ReInit();},_Mark:function(E){var A;C.U._Mark.call(this,E);if((A=this.AT)&&(A._cycle
!=E))A._Mark(A._cycle=E);if((A=this.BU)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.Bv)&&(A._cycle!=E))A._Mark(A._cycle=E);B.ts(this.Ax,E);if((A=this.C7)&&(A._cycle
!=E))A._Mark(A._cycle=E);if((A=this.A9)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=
this.BR)._cycle!=E)A._Mark(A._cycle=E);},_className:"Core::Root"};C.Event={A8:0,
Dp:false,Eb:function(){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;
return ticksCount;},AY:function(aArg){this.A8=this.Eb();},_Init:function(aArg){this.
__proto__=C.Event;this.AY(aArg);B.gv++;},_Done:function(){this.__proto__=null;B.
gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.N)&&(A._cycle!=E)
)A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::Event"};
C.KeyEvent={Ak:0,R:0,Down:false,Initialize2:function(Ai,A5){this.Ak=0;this.R=Ai;
this.Down=A5;if((Ai>=0x30)&&(Ai<=0x39))this.Ak=(10+Ai)-48;if((Ai>=0x41)&&(Ai<=0x5A
))this.Ak=(105+Ai)-65;if((Ai>=0x61)&&(Ai<=0x7A))this.Ak=(105+Ai)-97;if(Ai===0x20
)this.Ak=131;if(!this.Ak)switch(Ai){case 0x2B:this.Ak=132;break;case 0x2D:this.Ak=
133;break;case 0x2A:this.Ak=134;break;case 0x2F:this.Ak=135;break;case 0x3D:this.
Ak=136;break;case 0x2E:this.Ak=137;break;case 0x2C:this.Ak=138;break;case 0x3A:this.
Ak=139;break;case 0x3B:this.Ak=140;break;default:;}return this;},Initialize:function(
Ai,A5){this.Ak=Ai;this.Down=A5;this.R=0x00;var Ff=Ai-10;var Fe=Ai-105;if((Ff>=0)&&(
Ff<=9))this.R=(48+Ff)&0xFFFF;if((Fe>=0)&&(Fe<=25))this.R=(65+Fe)&0xFFFF;if(Ai===
131)this.R=0x20;if(this.R===0x00)switch(Ai){case 132:this.R=0x2B;break;case 133:
this.R=0x2D;break;case 134:this.R=0x2A;break;case 135:this.R=0x2F;break;case 136:
this.R=0x3D;break;case 137:this.R=0x2E;break;case 138:this.R=0x2C;break;case 139:
this.R=0x3A;break;case 140:this.R=0x3B;break;default:;}return this;},GQ:function(
Gj){switch(Gj){case 141:return((this.R>=0x41)&&(this.R<=0x5A))||((this.R>=0x61)&&(
this.R<=0x7A));case 142:return(((this.R>=0x41)&&(this.R<=0x5A))||((this.R>=0x61)&&(
this.R<=0x7A)))||((this.R>=0x30)&&(this.R<=0x39));case 143:return(this.R>=0x30)&&(
this.R<=0x39);case 144:return(((this.R>=0x41)&&(this.R<=0x46))||((this.R>=0x61)&&(
this.R<=0x66)))||((this.R>=0x30)&&(this.R<=0x39));case 145:return this.R!==0x00;
case 146:return(this.R===0x00)&&!!this.Ak;case 147:return(((this.Ak===6)||(this.
Ak===7))||(this.Ak===4))||(this.Ak===5);case 148:return(this.R!==0x00)||!!this.Ak;
default:;}return Gj===this.Ak;},_Init:function(aArg){C.Event._Init.call(this,aArg
);this.__proto__=C.KeyEvent;},_className:"Core::KeyEvent"};C.ES={E4:null,B1:B.qx
,B3:0,B0:0,Down:false,Dg:false,InitializeUp:function(I,A_,Cz,Fc,Bj){this.Down=false;
this.B0=I;this.B3=A_;this.B1=Bj;this.E4=Fc;this.Dg=Cz;return this;},InitializeDown:
function(I,A_,Cz,Fc,Bj){this.Down=true;this.B0=I;this.B3=A_;this.B1=Bj;this.E4=Fc;
this.Dg=Cz;return this;},_Init:function(aArg){C.Event._Init.call(this,aArg);this.
__proto__=C.ES;},_Mark:function(E){var A;C.Event._Mark.call(this,E);if((A=this.E4
)&&(A._cycle!=E))A._Mark(A._cycle=E);},_className:"Core::CursorGrabEvent"};C.ER={
Dl:B.qx,B1:B.qx,B3:0,Dn:0,Dm:B.qx,Dh:B.qx,B0:0,Down:false,Dg:false,InitializeHold:
function(I,B$,DK,DL,A_,Bu,Bj,DJ){this.Down=true;this.B0=I;this.Dh=B.tx(B$,Bu);this.
Dm=B.tx(DK,Bu);this.Dn=DL;this.B3=A_;this.B1=Bj;this.Dl=DJ;return this;},InitializeUp:
function(I,B$,DK,DL,A_,Bu,Cz,Bj,DJ){this.Down=false;this.B0=I;this.Dh=B.tx(B$,Bu
);this.Dm=B.tx(DK,Bu);this.Dn=DL;this.B3=A_;this.Dg=Cz;this.B1=Bj;this.Dl=DJ;return this;
},InitializeDown:function(I,B$,A_,Bu,Cz,Bj){this.Down=true;this.B0=I;this.Dh=B.tx(
B$,Bu);this.Dm=B.tx(B$,Bu);this.Dn=0;this.B3=A_;this.Dg=Cz;this.B1=Bj;this.Dl=Bj;
return this;},_Init:function(aArg){C.Event._Init.call(this,aArg);this.__proto__=
C.ER;},_className:"Core::CursorEvent"};C.ET={Dl:B.qx,B1:B.qx,B3:0,Dn:0,EZ:B.qx,Dm:
B.qx,Dh:B.qx,B0:0,Initialize:function(I,B$,DK,aOffset,DL,HF,Bu,Bj,DJ){this.B0=I;
this.Dh=B.tx(B$,Bu);this.Dm=B.tx(DK,Bu);this.EZ=aOffset;this.Dn=DL;this.B3=HF;this.
B1=Bj;this.Dl=DJ;return this;},_Init:function(aArg){C.Event._Init.call(this,aArg
);this.__proto__=C.ET;},_className:"Core::DragEvent"};C.DA={B2:null,DD:B.qx,G6:0
,G4:0,Space:0,Ea:0,Bs:function(Am,aClip,aOffset,At,aBlend){},Al:function(D){var A;
if(B.tm(D,this.K))return;var Cl=[(A=this.K)[2]-A[0],A[3]-A[1]];var ED=[D[2]-D[0]
,D[3]-D[1]];var CP=!B.tl(Cl,ED);var DY=B.tw(D.slice(0,2),this.K.slice(0,2));if(!
B.tl(DY,W)&&!CP){var G=this.Ay;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400
)===0x400)){var tmp=((G.F&0x100)===0x100);G.FQ(DY,tmp);}G=G.Ay;}B.lq(this.B2,this
);}if((CP&&(Cl[0]>0))&&(Cl[1]>0)){var Ae=B.tz(this.K,this.DD);var G=this.Ay;var DT=
0x14;while(!!G&&!((G.F&0x200)===0x200)){if(((G.F&0x400)===0x400)){if(!!G.AD&&(G.
AD.Da!==this))G.AD=null;if(!G.AD&&((G.Cu!==DT)||!!this.Ea))G.Ew(Ae,this);}G=G.Ay;
}B.lq(this.B2,this);}C.AI.Al.call(this,D);if(!!this.J&&CP){this.F=this.F|0x1000;
if(!((this.J.F&0x2000)===0x2000)){this.J.F=this.J.F|0x4000;B.lq([A=this.J,A.BB],
this);}}},_Init:function(aArg){C.AI._Init.call(this,aArg);this.__proto__=C.DA;this.
F=0x203;},_Mark:function(E){var A;C.AI._Mark.call(this,E);if((A=this.B2)&&((A=A[
0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Core::Outline"};C.Ec={Ay:null,Ga:
null,F$:null,F_:null,CO:0,A8:0,Gf:0,GM:148,Ak:0,R:0,CU:true,Down:false,E2:false,
D8:false,AH:function(P){var A;if(!!P&&P.GQ(this.GM)){this.Down=P.Down;this.Ak=P.
Ak;this.R=P.R;this.A8=P.A8;this.D8=false;if(P.Down){this.Gf=this.CO;this.E2=this.
CO>0;if(this.E2)(A=this.F_)?A[1].call(A[0],this):null;else(A=this.F$)?A[1].call(
A[0],this):null;if(!this.D8)this.CO=this.CO+1;return!this.D8;}if(!P.Down){this.E2=
this.CO>1;this.Gf=this.CO-1;this.CO=0;(A=this.Ga)?A[1].call(A[0],this):null;return!
this.D8;}}return false;},AY:function(aArg){var A;var AV=(C.U.isPrototypeOf(A=this.
N)?A:null);if(!AV)throw new Error(E7);this.Ay=AV.Ez;AV.Ez=this;},_Init:function(
aArg){this.__proto__=C.Ec;this.AY(aArg);B.gv++;},_Done:function(){this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.Ay)&&(A._cycle
!=E))A._Mark(A._cycle=E);if((A=this.Ga)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E
);if((A=this.F$)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.F_)&&((A=A[
0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=
E);},N:null,_cycle:0,_observers:null,_className:"Core::KeyPressHandler"};C.GG={Bt:
null,D_:0,EZ:B.qx,_Init:function(aArg){this.__proto__=C.GG;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.Bt)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(
A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::CursorHit"};C.GR={
AV:null,_Init:function(aArg){this.__proto__=C.GR;B.gv++;},_Done:function(){this.
__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.
AV)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=
E);},N:null,_cycle:0,_observers:null,_className:"Core::ModalContext"};C.FO={Da:null
,Cg:B.qy,Ae:B.qy,isEmpty:false,_Init:function(aArg){this.__proto__=C.FO;B.gv++;}
,_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(
E){var A;if((A=this.Da)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle
!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::LayoutContext"
};C.GI={AV:null,_Init:function(aArg){this.__proto__=C.GI;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.AV)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(
A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::DialogContext"};
C.G8={Fh:null,Bx:null,_Init:function(aArg){this.__proto__=C.G8;B.gv++;},_Done:function(
){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((
A=this.Fh)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Bx)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:
null,_className:"Core::TaskQueue"};C.G7={_Init:function(aArg){this.__proto__=C.G7;
B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.N)&&(A._cycle!=E))A._Mark(A._cycle=E);},N:null,_cycle:
0,_observers:null,_className:"Core::Task"};C.BP={resource:null,Br:function(){this.
resource=null;},AY:function(aArg){this.resource=aArg;},_Init:function(aArg){this.
__proto__=C.BP;this.AY(aArg);B.gv++;},_Done:function(){this.Br();this.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){var A;if((A=this.N)&&(A._cycle
!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Core::Resource"
};C.Timer={Ef:null,timer:null,A8:0,Period:1000,FG:0,CU:false,Br:function(){var tmp=
this.timer;if(!!tmp)tmp.DestroyTimer();this.timer=null;},FB:function(aBegin,aPeriod
){if(aBegin<0)aBegin=0;if(aPeriod<0)aPeriod=0;var tmp=this.timer;if(!tmp&&((aBegin>
0)||(aPeriod>0)))tmp=B.sL(this,this.Trigger);if(!!tmp){tmp.ResetTimer();tmp.StartTimer(
aBegin,aPeriod);}this.timer=tmp;},G0:function(D){if(D<0)D=0;if(D===this.Period)return;
this.Period=D;if(this.CU)this.FB(this.FG,D);},Ed:function(D){if(D===this.CU)return;
this.CU=D;if(D)this.FB(this.FG,this.Period);else this.FB(0,0);this.A8=this.Eb();
},Eb:function(){var ticksCount=0;ticksCount=((new Date).getTime()-B.qt)|0;return ticksCount;
},Trigger:function(){var A;this.A8=this.Eb();if(!this.Period)this.Ed(false);(A=this.
Ef)?A[1].call(A[0],this):null;},_Init:function(aArg){this.__proto__=C.Timer;B.gv++;
},_Done:function(){this.Br();this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.Ef)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=
this.N)&&(A._cycle!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:
"Core::Timer"};C.IK={IL:0x1,H5:0x2,Ic:0x4,II:0x8,CU:0x10,IC:0x20,Id:0x40,Il:0x80
,Ib:0x100,Ig:0x200,Ia:0x400,Ir:0x800,Eh:0x1000,IJ:0x2000,Ip:0x4000,Iq:0x8000,H_:
0x10000,Io:0x20000,IB:0x40000};C.Cu={Is:0x1,It:0x2,HZ:0x4,H0:0x8,H1:0x10,HY:0x20
};C.Ea={Im:0,IF:1,H7:2,Ih:3,Iv:4,IG:5,IH:6,H8:7,H9:8,Ij:9,Ii:10,Ix:11,Iw:12};C.KeyCode={
NoKey:0,Ok:1,Exit:2,Menu:3,Up:4,Down:5,Left:6,Right:7,PageUp:8,PageDown:9,Key0:10
,Key1:11,Key2:12,Key3:13,Key4:14,Key5:15,Key6:16,Key7:17,Key8:18,Key9:19,Red:20,
Green:21,Blue:22,Yellow:23,White:24,Magenta:25,F1:26,F2:27,F3:28,F4:29,F5:30,F6:
31,F7:32,F8:33,F9:34,F10:35,ChannelUp:36,ChannelDown:37,Display:38,SkipPrev:39,SkipNext:
40,Home:41,End:42,Insert:43,Delete:44,Clear:45,VolumeUp:46,VolumeDown:47,Show:48
,Hide:49,Play:50,Pause:51,Record:52,Stop:53,Rev:54,Fwd:55,SlowRev:56,SlowFwd:57,
SkipBwd:58,SkipFwd:59,Repeat:60,Eject:61,Help:62,TV:63,DVD:64,VCR:65,EPG:66,OSD:
67,Text:68,PIP:69,Audio:70,Clock:71,Timer:72,Navigation:73,Karaoke:74,Game:75,Subtitle:
76,Zoom:77,Index:78,Info:79,Power:80,Setup:81,Angle:82,Mode:83,Mute:84,User0:85,
User1:86,User2:87,User3:88,User4:89,User5:90,User6:91,User7:92,User8:93,User9:94
,User10:95,User11:96,User12:97,User13:98,User14:99,User15:100,User16:101,User17:
102,User18:103,User19:104,KeyA:105,KeyB:106,KeyC:107,KeyD:108,KeyE:109,KeyF:110,
KeyG:111,KeyH:112,KeyI:113,KeyJ:114,KeyK:115,KeyL:116,KeyM:117,KeyN:118,KeyO:119
,KeyP:120,KeyQ:121,KeyR:122,KeyS:123,KeyT:124,KeyU:125,KeyV:126,KeyW:127,KeyX:128
,KeyY:129,KeyZ:130,Space:131,Plus:132,Minus:133,Multiply:134,Divide:135,Equals:136
,Period:137,Comma:138,Colon:139,Semicolon:140,AlphaKeys:141,AlphaOrDigitKeys:142
,DigitKeys:143,HexDigitKeys:144,CharacterKeys:145,ControlKeys:146,CursorKeys:147
,AnyKey:148,Enter:149,Escape:150,Backspace:151,Tab:152,CtrlKeyA:153,CtrlKeyB:154
,CtrlKeyC:155,CtrlKeyD:156,CtrlKeyE:157,CtrlKeyF:158,CtrlKeyG:159,CtrlKeyH:160,CtrlKeyI:
161,CtrlKeyJ:162,CtrlKeyK:163,CtrlKeyL:164,CtrlKeyM:165,CtrlKeyN:166,CtrlKeyO:167
,CtrlKeyP:168,CtrlKeyQ:169,CtrlKeyR:170,CtrlKeyS:171,CtrlKeyT:172,CtrlKeyU:173,CtrlKeyV:
174,CtrlKeyW:175,CtrlKeyX:176,CtrlKeyY:177,CtrlKeyZ:178,CtrlSpace:179,CtrlKey0:180
,CtrlKey1:181,CtrlKey2:182,CtrlKey3:183,CtrlKey4:184,CtrlKey5:185,CtrlKey6:186,CtrlKey7:
187,CtrlKey8:188,CtrlKey9:189,CtrlF1:190,CtrlF2:191,CtrlF3:192,CtrlF4:193,CtrlF5:
194,CtrlF6:195,CtrlF7:196,CtrlF8:197,CtrlF9:198,CtrlF10:199,CtrlEnter:200,CtrlEscape:
201,CtrlUp:202,CtrlDown:203,CtrlLeft:204,CtrlRight:205,CtrlPageUp:206,CtrlPageDown:
207,CtrlBackspace:208,CtrlInsert:209,CtrlDelete:210,CtrlHome:211,CtrlEnd:212,CtrlTab:
213,CtrlShiftKeyA:214,CtrlShiftKeyB:215,CtrlShiftKeyC:216,CtrlShiftKeyD:217,CtrlShiftKeyE:
218,CtrlShiftKeyF:219,CtrlShiftKeyG:220,CtrlShiftKeyH:221,CtrlShiftKeyI:222,CtrlShiftKeyJ:
223,CtrlShiftKeyK:224,CtrlShiftKeyL:225,CtrlShiftKeyM:226,CtrlShiftKeyN:227,CtrlShiftKeyO:
228,CtrlShiftKeyP:229,CtrlShiftKeyQ:230,CtrlShiftKeyR:231,CtrlShiftKeyS:232,CtrlShiftKeyT:
233,CtrlShiftKeyU:234,CtrlShiftKeyV:235,CtrlShiftKeyW:236,CtrlShiftKeyX:237,CtrlShiftKeyY:
238,CtrlShiftKeyZ:239,CtrlShiftSpace:240,CtrlShiftKey0:241,CtrlShiftKey1:242,CtrlShiftKey2:
243,CtrlShiftKey3:244,CtrlShiftKey4:245,CtrlShiftKey5:246,CtrlShiftKey6:247,CtrlShiftKey7:
248,CtrlShiftKey8:249,CtrlShiftKey9:250,CtrlShiftF1:251,CtrlShiftF2:252,CtrlShiftF3:
253,CtrlShiftF4:254,CtrlShiftF5:255,CtrlShiftF6:256,CtrlShiftF7:257,CtrlShiftF8:
258,CtrlShiftF9:259,CtrlShiftF10:260,CtrlShiftEnter:261,CtrlShiftEscape:262,CtrlShiftUp:
263,CtrlShiftDown:264,CtrlShiftLeft:265,CtrlShiftRight:266,CtrlShiftPageUp:267,CtrlShiftPageDown:
268,CtrlShiftBackspace:269,CtrlShiftInsert:270,CtrlShiftDelete:271,CtrlShiftHome:
272,CtrlShiftEnd:273,CtrlShiftTab:274,AltF1:275,AltF2:276,AltF3:277,AltF4:278,AltF5:
279,AltF6:280,AltF7:281,AltF8:282,AltF9:283,AltF10:284,AltEnter:285,AltEscape:286
,AltUp:287,AltDown:288,AltLeft:289,AltRight:290,AltPageUp:291,AltPageDown:292,AltBackspace:
293,AltInsert:294,AltDelete:295,AltHome:296,AltEnd:297,AltTab:298,AltShiftF1:299
,AltShiftF2:300,AltShiftF3:301,AltShiftF4:302,AltShiftF5:303,AltShiftF6:304,AltShiftF7:
305,AltShiftF8:306,AltShiftF9:307,AltShiftF10:308,AltShiftEnter:309,AltShiftEscape:
310,AltShiftUp:311,AltShiftDown:312,AltShiftLeft:313,AltShiftRight:314,AltShiftPageUp:
315,AltShiftPageDown:316,AltShiftBackspace:317,AltShiftInsert:318,AltShiftDelete:
319,AltShiftHome:320,AltShiftEnd:321,AltShiftTab:322,ShiftF1:323,ShiftF2:324,ShiftF3:
325,ShiftF4:326,ShiftF5:327,ShiftF6:328,ShiftF7:329,ShiftF8:330,ShiftF9:331,ShiftF10:
332,ShiftEnter:333,ShiftEscape:334,ShiftUp:335,ShiftDown:336,ShiftLeft:337,ShiftRight:
338,ShiftPageUp:339,ShiftPageDown:340,ShiftBackspace:341,ShiftInsert:342,ShiftDelete:
343,ShiftHome:344,ShiftEnd:345,ShiftTab:346};C.Iu={IP:0x1,IM:0x2,IN:0x4,IO:0x8,Ik:
0x10,Ie:0x20};
C._Init=function(){C.AI.__proto__=C.Bt;C.U.__proto__=C.AI;C.Root.__proto__=C.U;C.
KeyEvent.__proto__=C.Event;C.ES.__proto__=C.Event;C.ER.__proto__=C.Event;C.ET.__proto__=
C.Event;C.DA.__proto__=C.AI;};C.Aw=function(E){};return C;})();

/* Embedded Wizard */