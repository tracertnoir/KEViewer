/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.un)throw new Error("The unit file 'BrowserDevice.js' included twice!"
);EmWiApp.un=(function(){var B=EmWiApp;var C={};

C.A4={Ei:function(){var raw=B.tA(100,B.hm,null);var iraw=B.tA(20,0,null);var H;for(
H=0;H<100;H=H+1)raw.Set(H,B.hm);for(H=0;H<20;H=H+1)iraw.Set(H,0);{doSend("GET_DATA..."
);if(Object.keys(jsonDatas).length>0){console.log("JsonCount = "+Object.keys(jsonDatas
).length);raw[0]=jsonDatas.LOTID;raw[1]=jsonDatas.STEP_CODE;raw[2]=jsonDatas.RECIPE_NAME;
raw[3]=jsonDatas.JOB_TIME;raw[4]=jsonDatas.EVENT_TIME;raw[5]=jsonDatas.HOLD_TIME;
raw[6]=jsonDatas.TOTAL_TIME;iraw[0]=parseFloat(jsonDatas.TEMP_FFC_01)*10;iraw[1]=
parseFloat(jsonDatas.TEMP_FFC_02)*10;iraw[2]=parseFloat(jsonDatas.TEMP_FFC_03)*10;
iraw[3]=parseFloat(jsonDatas.TEMP_DDC_01)*10;iraw[4]=parseFloat(jsonDatas.TEMP_DDC_02
)*10;iraw[5]=parseFloat(jsonDatas.TEMP_DDC_03)*10;}}this.C0(raw.Get(0));this.Dz(
raw.Get(1));this.C1(raw.Get(2));this.CZ(raw.Get(3));this.CY(raw.Get(4));this.CX(
raw.Get(5));this.C2(raw.Get(6));this.Dv(iraw.Get(0));this.Dw(iraw.Get(1));this.Dx(
iraw.Get(2));this.Ds(iraw.Get(3));this.Dt(iraw.Get(4));this.Du(iraw.Get(5));B.uf(
"%i",this.Ct);},Ej:function(){init_websocket();},Dz:function(D){},C0:function(D){
if(this.Dr===D)return;this.Dr=D;B.tG([this,this.FY,this.C0],0);},C1:function(D){
if(this.DC===D)return;this.DC=D;B.tG([this,this.FZ,this.C1],0);},CZ:function(D){
if(this.Dq===D)return;this.Dq=D;B.tG([this,this.FX,this.CZ],0);},CX:function(D){
if(this.Dj===D)return;this.Dj=D;B.tG([this,this.FU,this.CX],0);},CY:function(D){
if(this.Do===D)return;this.Do=D;B.tG([this,this.FW,this.CY],0);},C2:function(D){
if(this.DF===D)return;this.DF=D;B.tG([this,this.F0,this.C2],0);},Dv:function(D){
if(this.Ct===D)return;this.Ct=D;B.tG([this,this.GU,this.Dv],0);},Ds:function(D){
if(this.CT===D)return;this.CT=D;B.tG([this,this.GS,this.Ds],0);},Dw:function(D){
if(this.BO===D)return;this.BO=D;B.tG([this,this.GV,this.Dw],0);},Dt:function(D){
if(this.BN===D)return;this.BN=D;B.tG([this,this.GT,this.Dt],0);},Dx:function(D){
if(this.FK===D)return;this.FK=D;B.tG([this,this.FV,this.Dx],0);},Du:function(D){
if(this.FI===D)return;this.FI=D;B.tG([this,this.FT,this.Du],0);},_Init:function(
aArg){var L=this.L;L.__proto__=C.A4;B.gv++;},_Done:function(){var L=this.L;L.__proto__=
null;B.gv--;},_ReInit:function(){},_Mark:function(E){},_variants:function(){return this;
},_className:"BrowserDevice::DeviceClass"};var eqDatas;var jsonDatas;function init_websocket(
){var wsUri="ws://"+location.hostname+":5080/";websocket=new WebSocket(wsUri);websocket.
onopen=function(evt){onOpen(evt)};websocket.onclose=function(evt){onClose(evt)};
websocket.onmessage=function(evt){onMessage(evt)};websocket.onerror=function(evt
){onError(evt)};}function onOpen(evt){console.log("onOpen");}function onClose(evt
){console.log("onClose");}function onMessage(evt){console.log(evt.data);jsonDatas=
JSON.parse(evt.data);}function onError(evt){console.log("onError");}function doSend(
message){console.log("doSend");if(websocket.readyState==1){websocket.send(message
);}console.log(websocket.readyState);}
C._Init=function(){};C.Aw=function(E){};return C;})();

/* Embedded Wizard */