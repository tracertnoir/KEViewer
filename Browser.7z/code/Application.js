/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var C={};
var W="init...";var Ap="get data...";var B_=[0,0,1024,768];var DG=[0,0,1030,770];
var DH=[20,30,150,90];var DI="LOT-ID";var E7="SK0012";var G_=[160,30,290,90];var
G$="RECIPE";var Ha=[300,30,430,90];var Hb="Step";var Hc=[440,30,570,90];var Hd="JOB TIME";
var He=[580,30,710,90];var Hf="EVENT TIME";var Hg=[720,30,850,90];var Hh="HOLD TIME";
var Hi=[860,30,990,90];var Hj="TOTAL TIME";var Hk=[20,120,570,450];var Hl="Unit";
var Hm="Name";var Gh=[0,0,170,70];var Hn=[4,1,170,20];var Ho=[0,10,170,70];
C.EN={AB:null,AJ:null,B4:null,B5:null,B6:null,B7:null,B8:null,B9:null,Timer:null,
A3:null,Ao:null,AY:function(aArg){B.uf("%s",W);B._GetAutoObject(B.Device.Device).
Ej();},G3:function(Dc){B.uf("%s",Ap);B._GetAutoObject(B.Device.Device).Ei();this.
G9();},G9:function(){this.Ao.GE();this.Ao.CS(B._GetAutoObject(B.Device.Device).Ct
,0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).BO,0xFFC8C8C8);this.Ao.
CS(B._GetAutoObject(B.Device.Device).FV(),0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(
B.Device.Device).CT,0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).BN,
0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).FT(),0xFFC8C8C8);this.A3.
G1(this.Ao);},_Init:function(aArg){B.Core.Root._Init.call(this,aArg);B.uk.AB._Init.
call(this.AB={N:this},0);C.AJ._Init.call(this.AJ={N:this},0);C.AJ._Init.call(this.
B4={N:this},0);C.AJ._Init.call(this.B5={N:this},0);C.AJ._Init.call(this.B6={N:this
},0);C.AJ._Init.call(this.B7={N:this},0);C.AJ._Init.call(this.B8={N:this},0);C.AJ.
_Init.call(this.B9={N:this},0);B.Core.Timer._Init.call(this.Timer={N:this},0);B.
ul.A3._Init.call(this.A3={N:this},0);B.ul.Ge._Init.call(this.Ao={N:this},0);this.
__proto__=C.EN;var A;this.Al(B_);this.AB.Al(DG);this.AB.CW(0xF8F8F8F8);this.AJ.Al(
DH);this.AJ.Cw(DI);this.AJ.Gd(E7);this.B4.Al(G_);this.B4.Cw(G$);this.B5.Al(Ha);this.
B5.Cw(Hb);this.B6.Al(Hc);this.B6.Cw(Hd);this.B7.Al(He);this.B7.Cw(Hf);this.B8.Al(
Hg);this.B8.Cw(Hh);this.B9.Al(Hi);this.B9.Cw(Hj);this.Timer.Ed(true);this.A3.Al(
Hk);this.A3.GY(1000);this.A3.GX(0xFF696969);this.A3.GZ(0);this.A7(this.AB,0);this.
A7(this.AJ,0);this.A7(this.B4,0);this.A7(this.B5,0);this.A7(this.B6,0);this.A7(this.
B7,0);this.A7(this.B8,0);this.A7(this.B9,0);this.A7(this.A3,0);this.AJ.Cv([A=B._GetAutoObject(
B.Device.Device),A.FY,A.C0]);this.B4.Cv([A=B._GetAutoObject(B.Device.Device),A.FZ
,A.C1]);this.B5.Cv([A=B._GetAutoObject(B.Device.Device),A.GW,A.Dz]);this.B6.Cv([
A=B._GetAutoObject(B.Device.Device),A.FX,A.CZ]);this.B7.Cv([A=B._GetAutoObject(B.
Device.Device),A.FU,A.CX]);this.B8.Cv([A=B._GetAutoObject(B.Device.Device),A.FW,
A.CY]);this.B9.Cv([A=B._GetAutoObject(B.Device.Device),A.F0,A.C2]);this.Timer.Ef=[
this,this.G3];this.AY(aArg);},_Done:function(){this.__proto__=B.Core.Root;this.AB.
_Done();this.AJ._Done();this.B4._Done();this.B5._Done();this.B6._Done();this.B7.
_Done();this.B8._Done();this.B9._Done();this.Timer._Done();this.A3._Done();this.
Ao._Done();B.Core.Root._Done.call(this);},_ReInit:function(){B.Core.Root._ReInit.
call(this);this.AB._ReInit();this.AJ._ReInit();this.B4._ReInit();this.B5._ReInit(
);this.B6._ReInit();this.B7._ReInit();this.B8._ReInit();this.B9._ReInit();this.Timer.
_ReInit();this.A3._ReInit();this.Ao._ReInit();},_Mark:function(E){var A;B.Core.Root.
_Mark.call(this,E);if((A=this.AB)._cycle!=E)A._Mark(A._cycle=E);if((A=this.AJ)._cycle
!=E)A._Mark(A._cycle=E);if((A=this.B4)._cycle!=E)A._Mark(A._cycle=E);if((A=this.
B5)._cycle!=E)A._Mark(A._cycle=E);if((A=this.B6)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.B7)._cycle!=E)A._Mark(A._cycle=E);if((A=this.B8)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.B9)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Timer)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.A3)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Ao)._cycle!=
E)A._Mark(A._cycle=E);},_className:"Application::Application"};C.AJ={Cx:null,AB:
null,BA:null,Bp:null,Fj:Hl,Fk:Hm,Eh:function(aSize){B.Core.U.Eh.call(this,aSize);
},E6:function(Gn){B.Core.U.E6.call(this,Gn);},Cw:function(D){if(this.Fj===D)return;
this.Fj=D;this.BA.Ee(this.Fj);},Gd:function(D){if(this.Fk===D)return;this.Fk=D;this.
Bp.Ee(this.Fk);},Cv:function(D){if(B.tn(this.Cx,D))return;if(!!this.Cx)B.sO([this
,this.Ft],this.Cx,0);this.Cx=D;if(!!D)B.sB([this,this.Ft],D,0);if(!!D)B.lq([this
,this.Ft],this);},Ft:function(Dc){var A;if(!!this.Cx)this.Gd((A=this.Cx,A[1].call(
A[0])));},_Init:function(aArg){B.Core.U._Init.call(this,aArg);B.uk.AB._Init.call(
this.AB={N:this},0);B.uk.Text._Init.call(this.BA={N:this},0);B.uk.Text._Init.call(
this.Bp={N:this},0);this.__proto__=C.AJ;this.AB.E1(0x3F);this.AB.Al(Gh);this.Al(
Gh);this.BA.Al(Hn);this.BA.Gb(0x11);this.BA.Ee(DI);this.BA.CW(0xFF636363);this.Bp.
E1(0x3F);this.Bp.Al(Ho);this.Bp.Gb(0x12);this.Bp.Ee(DI);this.Bp.CW(0xFF636363);this.
A7(this.AB,0);this.A7(this.BA,0);this.A7(this.Bp,0);this.BA.Gc(B.s$(B.um.EX));this.
Bp.Gc(B.s$(B.um.EW));},_Done:function(){this.__proto__=B.Core.U;this.AB._Done();
this.BA._Done();this.Bp._Done();B.Core.U._Done.call(this);},_ReInit:function(){B.
Core.U._ReInit.call(this);this.AB._ReInit();this.BA._ReInit();this.Bp._ReInit();
},_Mark:function(E){var A;B.Core.U._Mark.call(this,E);if((A=this.Cx)&&((A=A[0]).
_cycle!=E))A._Mark(A._cycle=E);if((A=this.AB)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.BA)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Bp)._cycle!=E)A._Mark(A._cycle=
E);},_className:"Application::StringRectDataBox"};
C._Init=function(){C.EN.__proto__=B.Core.Root;C.AJ.__proto__=B.Core.U;};C.Aw=function(
E){};return C;})();

/* Embedded Wizard */