/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ia)throw new Error("The unit file 'Application.js' included twice!"
);EmWiApp.ia=(function(){var B=EmWiApp;var C={};
var W="init...";var Ap="get data...";var B_=[0,0,1024,768];var DG=[0,0,1030,770];
var DH=[20,30,150,90];var DI="LOT-ID";var E8="SK0012";var G_=[160,30,290,90];var
G$="RECIPE";var Ha="P2500-4.75";var Hb=[300,30,430,90];var Hc="Step";var Hd=[440
,30,570,90];var He="JOB TIME";var Hf=[580,30,710,90];var Hg="EVENT TIME";var Hh=[
720,30,850,90];var Hi="HOLD TIME";var Hj=[860,30,990,90];var Hk="TOTAL TIME";var
Hl=[20,120,500,450];var Hm="Unit";var Hn="Name";var Gh=[0,0,170,70];var Ho=[4,1,
170,20];var Hp=[0,10,170,70];
C.EN={AB:null,AJ:null,BQ:null,B5:null,B6:null,B7:null,B8:null,B9:null,Timer:null,
A3:null,Ao:null,AY:function(aArg){B.uf("%s",W);B._GetAutoObject(B.Device.Device).
Ej();},G3:function(Dc){B.uf("%s",Ap);B._GetAutoObject(B.Device.Device).Ei();this.
G9();},G9:function(){this.Ao.GE();this.Ao.CS(B._GetAutoObject(B.Device.Device).Ct
,0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).BO,0xFFC8C8C8);this.Ao.
CS(B._GetAutoObject(B.Device.Device).FW(),0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(
B.Device.Device).CT,0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).BN,
0xFFC8C8C8);this.Ao.CS(B._GetAutoObject(B.Device.Device).FU(),0xFFC8C8C8);this.A3.
G1(this.Ao);},_Init:function(aArg){B.Core.Root._Init.call(this,aArg);B.uk.AB._Init.
call(this.AB={N:this},0);C.AJ._Init.call(this.AJ={N:this},0);C.AJ._Init.call(this.
BQ={N:this},0);C.AJ._Init.call(this.B5={N:this},0);C.AJ._Init.call(this.B6={N:this
},0);C.AJ._Init.call(this.B7={N:this},0);C.AJ._Init.call(this.B8={N:this},0);C.AJ.
_Init.call(this.B9={N:this},0);B.Core.Timer._Init.call(this.Timer={N:this},0);B.
ul.A3._Init.call(this.A3={N:this},0);B.ul.Ge._Init.call(this.Ao={N:this},0);this.
__proto__=C.EN;var A;this.Al(B_);this.AB.Al(DG);this.AB.CW(0xF8F8F8F8);this.AJ.Al(
DH);this.AJ.Cw(DI);this.AJ.E2(E8);this.BQ.Al(G_);this.BQ.Cw(G$);this.BQ.E2(Ha);this.
B5.Al(Hb);this.B5.Cw(Hc);this.B6.Al(Hd);this.B6.Cw(He);this.B7.Al(Hf);this.B7.Cw(
Hg);this.B8.Al(Hh);this.B8.Cw(Hi);this.B9.Al(Hj);this.B9.Cw(Hk);this.Timer.Ed(true
);this.A3.Al(Hl);this.A3.GY(10000);this.A3.GX(0xFF696969);this.A3.GZ(0);this.A7(
this.AB,0);this.A7(this.AJ,0);this.A7(this.BQ,0);this.A7(this.B5,0);this.A7(this.
B6,0);this.A7(this.B7,0);this.A7(this.B8,0);this.A7(this.B9,0);this.A7(this.A3,0
);this.AJ.Cv([A=B._GetAutoObject(B.Device.Device),A.FZ,A.C0]);this.BQ.Cv([A=B._GetAutoObject(
B.Device.Device),A.F0,A.C1]);this.B5.Cv([A=B._GetAutoObject(B.Device.Device),A.GW
,A.Dz]);this.B6.Cv([A=B._GetAutoObject(B.Device.Device),A.FY,A.CZ]);this.B7.Cv([
A=B._GetAutoObject(B.Device.Device),A.FV,A.CX]);this.B8.Cv([A=B._GetAutoObject(B.
Device.Device),A.FX,A.CY]);this.B9.Cv([A=B._GetAutoObject(B.Device.Device),A.F_,
A.C2]);this.Timer.Ef=[this,this.G3];this.AY(aArg);},_Done:function(){this.__proto__=
B.Core.Root;this.AB._Done();this.AJ._Done();this.BQ._Done();this.B5._Done();this.
B6._Done();this.B7._Done();this.B8._Done();this.B9._Done();this.Timer._Done();this.
A3._Done();this.Ao._Done();B.Core.Root._Done.call(this);},_ReInit:function(){B.Core.
Root._ReInit.call(this);this.AB._ReInit();this.AJ._ReInit();this.BQ._ReInit();this.
B5._ReInit();this.B6._ReInit();this.B7._ReInit();this.B8._ReInit();this.B9._ReInit(
);this.Timer._ReInit();this.A3._ReInit();this.Ao._ReInit();},_Mark:function(E){var
A;B.Core.Root._Mark.call(this,E);if((A=this.AB)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.AJ)._cycle!=E)A._Mark(A._cycle=E);if((A=this.BQ)._cycle!=E)A._Mark(A._cycle=
E);if((A=this.B5)._cycle!=E)A._Mark(A._cycle=E);if((A=this.B6)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.B7)._cycle!=E)A._Mark(A._cycle=E);if((A=this.B8)._cycle!=
E)A._Mark(A._cycle=E);if((A=this.B9)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Timer
)._cycle!=E)A._Mark(A._cycle=E);if((A=this.A3)._cycle!=E)A._Mark(A._cycle=E);if((
A=this.Ao)._cycle!=E)A._Mark(A._cycle=E);},_className:"Application::Application"
};C.AJ={Cx:null,AB:null,BA:null,Bp:null,Fk:Hm,Fl:Hn,Eh:function(aSize){B.Core.U.
Eh.call(this,aSize);},E7:function(Gn){B.Core.U.E7.call(this,Gn);},Cw:function(D){
if(this.Fk===D)return;this.Fk=D;this.BA.Ee(this.Fk);},E2:function(D){if(this.Fl===
D)return;this.Fl=D;this.Bp.Ee(this.Fl);},Cv:function(D){if(B.tn(this.Cx,D))return;
if(!!this.Cx)B.sO([this,this.Fu],this.Cx,0);this.Cx=D;if(!!D)B.sB([this,this.Fu]
,D,0);if(!!D)B.lq([this,this.Fu],this);},Fu:function(Dc){var A;if(!!this.Cx)this.
E2((A=this.Cx,A[1].call(A[0])));},_Init:function(aArg){B.Core.U._Init.call(this,
aArg);B.uk.AB._Init.call(this.AB={N:this},0);B.uk.Text._Init.call(this.BA={N:this
},0);B.uk.Text._Init.call(this.Bp={N:this},0);this.__proto__=C.AJ;this.AB.E1(0x3F
);this.AB.Al(Gh);this.Al(Gh);this.BA.Al(Ho);this.BA.Gc(0x11);this.BA.Ee(DI);this.
BA.CW(0xFF636363);this.Bp.E1(0x3F);this.Bp.Al(Hp);this.Bp.Gc(0x12);this.Bp.Ee(DI
);this.Bp.CW(0xFF636363);this.A7(this.AB,0);this.A7(this.BA,0);this.A7(this.Bp,0
);this.BA.Gd(B.s$(B.um.EX));this.Bp.Gd(B.s$(B.um.EW));},_Done:function(){this.__proto__=
B.Core.U;this.AB._Done();this.BA._Done();this.Bp._Done();B.Core.U._Done.call(this
);},_ReInit:function(){B.Core.U._ReInit.call(this);this.AB._ReInit();this.BA._ReInit(
);this.Bp._ReInit();},_Mark:function(E){var A;B.Core.U._Mark.call(this,E);if((A=
this.Cx)&&((A=A[0])._cycle!=E))A._Mark(A._cycle=E);if((A=this.AB)._cycle!=E)A._Mark(
A._cycle=E);if((A=this.BA)._cycle!=E)A._Mark(A._cycle=E);if((A=this.Bp)._cycle!=
E)A._Mark(A._cycle=E);},_className:"Application::StringRectDataBox"};
C._Init=function(){C.EN.__proto__=B.Core.Root;C.AJ.__proto__=B.Core.U;};C.Aw=function(
E){};return C;})();

/* Embedded Wizard */