/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Graphics)throw new Error("The unit file 'Graphics.js' included twice!"
);EmWiApp.Graphics=(function(){var B=EmWiApp;var C={};
var W=[0,0];var Ap="Can not resize explicitly attached graphics engine bitmaps";var
B_=[0,0,0,0];var DG="No graphics engine bitmap attached to this canvas";var DH="The canvas is already initialized with a graphics engine bitmap";
C.Canvas={FS:null,Bh:B.qy,Di:0,DN:false,Br:function(){if(this.DN)this.DetachBitmap(
);},AY:function(aArg){this.FR=true;},E0:function(D){if((D[0]<=0)||(D[1]<=0))D=W;
if(B.tl(D,this.FrameSize))return;if(this.DN)throw new Error(Ap);this.FrameSize=D;
this.Df=(((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))&&(this.FrameDelay>0))&&(
this.NoOfFrames>1);if(!this.bitmap)return;var handle=this.bitmap;B.sW(handle);this.
bitmap=null;},Update:function(){var A;if((!this.bitmap&&(this.FrameSize[0]>0))&&(
this.FrameSize[1]>0)){var frameSize=this.FrameSize;var noOfFrames=this.NoOfFrames;
var frameDelay=this.FrameDelay;var handle=null;{handle=B.nc(B.ch,frameSize,frameDelay
,noOfFrames);}this.bitmap=handle;if(!this.bitmap){this.FrameSize=W;this.FrameDelay=
0;this.NoOfFrames=1;}this.Bh=[].concat(W,this.FrameSize);}if(!(((A=this.Bh)[0]>=
A[2])||(A[1]>=A[3]))){if((this.FrameSize[0]>0)&&(this.FrameSize[1]>0))(A=this.FS
)?A[1].call(A[0],this):null;this.Bh=B_;}},DetachBitmap:function(){if(!this.DN)throw new
Error(DG);this.bitmap=null;this.DN=false;this.FrameSize=W;this.FrameDelay=0;this.
NoOfFrames=1;this.Df=false;return this;},AttachBitmap:function(aBitmap){if(!!this.
bitmap)throw new Error(DH);if(!aBitmap)return this;this.bitmap=aBitmap;this.DN=true;
var noOfFrames=1;var frameSize=W;var frameDelay=0;{noOfFrames=aBitmap.NoOfFrames;
frameSize=aBitmap.FrameSize;frameDelay=aBitmap.FrameDelay;}this.NoOfFrames=noOfFrames;
this.FrameSize=frameSize;this.FrameDelay=frameDelay;this.Df=(this.FrameDelay>0)&&(
this.NoOfFrames>1);return this;},FJ:function(aClip,E9,aString,aOffset,aCount,aDstRect
,aSrcPos,aMinWidth,E$,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.bitmap
)this.Update();if(!this.bitmap)return;if(aOffset<0)aOffset=0;if((!E9||!E9.font)||((
aOffset>0)&&(aOffset>=aString.length)))return;var orient=0;if(E$===1)orient=90;else
if(E$===2)orient=180;else if(E$===3)orient=270;var dstFrameNo=this.Di;var dstBitmap=
this.bitmap;var srcFont=E9.font;{B.nf(dstBitmap,srcFont,aString,aOffset,aCount,dstFrameNo
,aClip,aDstRect,aSrcPos,aMinWidth,orient,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
);}},GJ:function(aClip,aBitmap,aFrameNr,aDstRect,C5,aColorTL,aColorTR,aColorBR,aColorBL
,aBlend){var A;if(!this.bitmap)this.Update();if(!this.bitmap)return;if((((!aBitmap||
!aBitmap.bitmap)||!C5)||(aFrameNr<0))||(aFrameNr>=aBitmap.NoOfFrames))return;var
dstBitmap=this.bitmap;var srcBitmap=aBitmap.bitmap;var dstFrameNo=this.Di;var srcRect=[
].concat(W,aBitmap.FrameSize);var left=((C5&0x1)===0x1);var top=((C5&0x2)===0x2);
var right=((C5&0x4)===0x4);var bottom=((C5&0x8)===0x8);var interior=((C5&0x10)===
0x10);{B.sQ(dstBitmap,srcBitmap,dstFrameNo,aFrameNr,aClip,aDstRect,srcRect,left,
top,right,bottom,interior,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},GF:function(
aClip,aBitmap,aFrameNr,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR,aColorBL,aBlend
){if(!this.bitmap)this.Update();if(!this.bitmap)return;if(((!aBitmap||!aBitmap.bitmap
)||(aFrameNr<0))||(aFrameNr>=aBitmap.NoOfFrames))return;var dstBitmap=this.bitmap;
var srcBitmap=aBitmap.bitmap;var dstFrameNr=this.Di;{B.fF(dstBitmap,srcBitmap,dstFrameNr
,aFrameNr,aClip,aDstRect,aSrcPos,aColorTL,aColorTR,aColorBR,aColorBL,aBlend);}},
D$:function(aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL,aBlend){if(!this.
bitmap)this.Update();if(!this.bitmap)return;var dstBitmap=this.bitmap;var dstFrameNo=
this.Di;{B.hn(dstBitmap,dstFrameNo,aClip,aDstRect,aColorTL,aColorTR,aColorBR,aColorBL
,aBlend);}},GK:function(aClip,aDstPos1,aDstPos2,aColor1,aColor2,aBlend){if(!this.
bitmap)this.Update();if(!this.bitmap)return;var dstBitmap=this.bitmap;var dstFrameNo=
this.Di;{B.sS(dstBitmap,dstFrameNo,aClip,aDstPos1,aDstPos2,aColor1,aColor2,aBlend
);}},_Init:function(aArg){B.ui.Cr._Init.call(this,aArg);this.__proto__=C.Canvas;
this.AY(aArg);},_Done:function(){this.Br();this.__proto__=B.ui.Cr;B.ui.Cr._Done.
call(this);},_Mark:function(E){var A;B.ui.Cr._Mark.call(this,E);if((A=this.FS)&&((
A=A[0])._cycle!=E))A._Mark(A._cycle=E);},_className:"Graphics::Canvas"};C.H$={Left:
0x1,IE:0x2,Right:0x4,H6:0x8,If:0x10};
C._Init=function(){C.Canvas.__proto__=B.ui.Cr;};C.Aw=function(E){};return C;})();

/* Embedded Wizard */