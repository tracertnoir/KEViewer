/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.ul)throw new Error("The unit file 'Charts.js' included twice!");EmWiApp.
ul=(function(){var B=EmWiApp;var C={};
var W=[20,10];var Ap=[0,0,360,240];
C.Record={Ay:null,Gg:0,FH:0xFFFFFFFF,_Init:function(aArg){this.__proto__=C.Record;
B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(){},_Mark:
function(E){var A;if((A=this.Ay)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N
)&&(A._cycle!=E))A._Mark(A._cycle=E);},N:null,_cycle:0,_observers:null,_className:
"Charts::Record"};C.Ge={DS:null,DW:null,Bi:10,E5:0,GE:function(){this.DS=null;this.
DW=null;this.Bi=0;this.E5=0;},CS:function(Go,HE){var Bd=null;Bd=B._NewObject(C.Record
,0);Bd.Gg=Go;Bd.FH=HE;if(!this.DS){this.DS=Bd;this.DW=Bd;this.Bi=1;}else{this.DW.
Ay=Bd;this.DW=Bd;this.Bi=this.Bi+1;}this.E5=this.E5+Go;},_Init:function(aArg){this.
__proto__=C.Ge;B.gv++;},_Done:function(){this.__proto__=null;B.gv--;},_ReInit:function(
){},_Mark:function(E){var A;if((A=this.DS)&&(A._cycle!=E))A._Mark(A._cycle=E);if((
A=this.DW)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.N)&&(A._cycle!=E))A._Mark(
A._cycle=E);},N:null,_cycle:0,_observers:null,_className:"Charts::RecordList"};C.
A3={EQ:null,Ao:null,BM:null,D7:W,EY:100,FE:0xFF202020,GO:0xFF3F5F00,CV:5,G5:0,GD:
0,FF:0,Bs:function(Am,aClip,aOffset,At,aBlend){var A;var EE=0;var Fu=0;var Fv=0;
var Fw=0;var Fi=(this.K[0]+aOffset[0])+this.D7[0];var Et=(this.K[1]+aOffset[1])+
this.D7[1];var A$;var C$=this.GO;var EM;var Bq;var AX=((A=this.K)[2]-A[0])-(this.
D7[0]*2);var AW=((A=this.K)[3]-A[1])-(this.D7[1]*2);var Cq=this.G5;var Ca=this.GD;
var CQ;var BK=(((At+1)*this.Eg)>>8)+1;aBlend=aBlend&&((this.F&0x2)===0x2);if(BK<
256)C$=(C$&0x00FFFFFF)|((((((C$>>24)&0xFF)*BK)>>8)&0xFF)<<24);B.Core.U.Bs.call(this
,Am,aClip,aOffset,At,aBlend);if((this.CV>0)&&(((C$>>24)&0xFF)>0)){var H;for(H=0;
H<this.CV;H=H+1){if(this.CV>1)Bq=(((H*AW)/(this.CV-1))|0)+Et;else Bq=Et+AW;Am.GK(
aClip,[Fi,Bq],[Fi+AX,Bq],C$,C$,aBlend);}}if(!this.Ao||(this.Ao.Bi<1))return;if(!
Ca){if(!Cq)CQ=(AX/2)|0;else CQ=(this.Ao.Bi-1)*Cq;Ca=((AX-CQ)/this.Ao.Bi)|0;if(Ca<
1)Ca=1;}if(!Cq){CQ=this.Ao.Bi*Ca;if(this.Ao.Bi>1)Cq=((AX-CQ)/(this.Ao.Bi-1))|0;if(
Cq<0)Cq=0;}CQ=(this.Ao.Bi*Ca)+((this.Ao.Bi-1)*Cq);EM=((AX-CQ)/2)|0;var Bd=this.Ao.
DS;while(!!Bd){EE=Fi+EM;Fu=(Et+AW)-(((Bd.Gg*AW)/this.EY)|0);Fv=EE+Ca;Fw=Et+AW;A$=
Bd.FH;if(BK<256)A$=(A$&0x00FFFFFF)|((((((A$>>24)&0xFF)*BK)>>8)&0xFF)<<24);if(((A$>>
24)&0xFF)>0){if(!!this.EQ&&(this.FF>=0))Am.GJ(aClip,this.EQ,this.FF,[EE,Fu,Fv,Fw
],0x1F,A$,A$,A$,A$,aBlend);else Am.D$(aClip,[EE,Fu,Fv,Fw],A$,A$,A$,A$,aBlend);}EM=(
EM+Ca)+Cq;Bd=Bd.Ay;}},GY:function(D){var A;if(D<1)D=1;if(D===this.EY)return;this.
EY=D;this.AE([0,0,(A=this.K)[2]-A[0],A[3]-A[1]]);},GX:function(D){if(D===this.FE
)return;this.FE=D;this.BM.CW(D);},GZ:function(D){var A;if(D<0)D=0;if(D>10)D=10;if(
D===this.CV)return;this.CV=D;this.AE([0,0,(A=this.K)[2]-A[0],A[3]-A[1]]);},G1:function(
D){var A;this.Ao=D;this.FN();this.AE([0,0,(A=this.K)[2]-A[0],A[3]-A[1]]);},_Init:
function(aArg){B.Core.U._Init.call(this,aArg);B.uk.AB._Init.call(this.BM={N:this
},0);this.__proto__=C.A3;this.Al(Ap);this.BM.E1(0x3F);this.BM.Al(Ap);this.BM.CW(
0xFF202020);this.A7(this.BM,0);},_Done:function(){this.__proto__=B.Core.U;this.BM.
_Done();B.Core.U._Done.call(this);},_ReInit:function(){B.Core.U._ReInit.call(this
);this.BM._ReInit();},_Mark:function(E){var A;B.Core.U._Mark.call(this,E);if((A=
this.EQ)&&(A._cycle!=E))A._Mark(A._cycle=E);if((A=this.Ao)&&(A._cycle!=E))A._Mark(
A._cycle=E);if((A=this.BM)._cycle!=E)A._Mark(A._cycle=E);},_className:"Charts::BarChart"
};
C._Init=function(){C.A3.__proto__=B.Core.U;};C.Aw=function(E){};return C;})();

/* Embedded Wizard */