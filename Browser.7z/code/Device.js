/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.Device)throw new Error("The unit file 'Device.js' included twice!");
EmWiApp.Device=(function(){var B=EmWiApp;var C={};
var W="Sorry, but this device is not able to ring the bell!";
C.A4={E4:B.hm,Dr:B.hm,DC:B.hm,Dq:B.hm,Dj:B.hm,Do:B.hm,DF:B.hm,Ct:0,CT:0,BO:0,BN:0
,FL:0,FJ:0,Ei:function(){if(this.L&&this.L.Ei)return this.L.Ei.apply(this,arguments
);else return this.HD.apply(this,arguments);},HD:function(){B.uf("%s",W);},Ej:function(
){if(this.L&&this.L.Ej)return this.L.Ej.apply(this,arguments);else return this.HE.
apply(this,arguments);},HE:function(){B.uf("%s",W);},Dz:function(D){if(this.L&&this.
L.Dz)return this.L.Dz.apply(this,arguments);else return this.HB.apply(this,arguments
);},HB:function(D){if(this.E4===D)return;this.E4=D;},GW:function(){return this.E4;
},C0:function(D){if(this.L&&this.L.C0)return this.L.C0.apply(this,arguments);else
return this.Hz.apply(this,arguments);},Hz:function(D){if(this.Dr===D)return;this.
Dr=D;},FZ:function(){return this.Dr;},C1:function(D){if(this.L&&this.L.C1)return this.
L.C1.apply(this,arguments);else return this.HA.apply(this,arguments);},HA:function(
D){if(this.DC===D)return;this.DC=D;},F0:function(){return this.DC;},CZ:function(
D){if(this.L&&this.L.CZ)return this.L.CZ.apply(this,arguments);else return this.
Hy.apply(this,arguments);},Hy:function(D){if(this.Dq===D)return;this.Dq=D;},FY:function(
){return this.Dq;},CX:function(D){if(this.L&&this.L.CX)return this.L.CX.apply(this
,arguments);else return this.Ht.apply(this,arguments);},Ht:function(D){if(this.Dj===
D)return;this.Dj=D;},FV:function(){return this.Dj;},CY:function(D){if(this.L&&this.
L.CY)return this.L.CY.apply(this,arguments);else return this.Hx.apply(this,arguments
);},Hx:function(D){if(this.Do===D)return;this.Do=D;},FX:function(){return this.Do;
},C2:function(D){if(this.L&&this.L.C2)return this.L.C2.apply(this,arguments);else
return this.HC.apply(this,arguments);},HC:function(D){if(this.DF===D)return;this.
DF=D;},F_:function(){return this.DF;},Dv:function(D){if(this.L&&this.L.Dv)return this.
L.Dv.apply(this,arguments);else return this.Hu.apply(this,arguments);},Hu:function(
D){if(this.Ct===D)return;this.Ct=D;},GU:function(){return this.Ct;},Ds:function(
D){if(this.L&&this.L.Ds)return this.L.Ds.apply(this,arguments);else return this.
Hq.apply(this,arguments);},Hq:function(D){if(this.CT===D)return;this.CT=D;},GS:function(
){return this.CT;},Dw:function(D){if(this.L&&this.L.Dw)return this.L.Dw.apply(this
,arguments);else return this.Hv.apply(this,arguments);},Hv:function(D){if(this.BO===
D)return;this.BO=D;},GV:function(){return this.BO;},Dt:function(D){if(this.L&&this.
L.Dt)return this.L.Dt.apply(this,arguments);else return this.Hr.apply(this,arguments
);},Hr:function(D){if(this.BN===D)return;this.BN=D;},GT:function(){return this.BN;
},Dx:function(D){if(this.L&&this.L.Dx)return this.L.Dx.apply(this,arguments);else
return this.Hw.apply(this,arguments);},Hw:function(D){if(this.BO===D)return;this.
BO=D;},FW:function(){return this.BO;},Du:function(D){if(this.L&&this.L.Du)return this.
L.Du.apply(this,arguments);else return this.Hs.apply(this,arguments);},Hs:function(
D){if(this.BN===D)return;this.BN=D;},FU:function(){return this.BN;},_Init:function(
aArg){B.uj.A4._Init.call(this,aArg);this.__proto__=C.A4;var Gi=this._variants();
if(Gi){this.L={};Gi._Init.call(this,aArg);}},_Done:function(){if(this.L)this.L._Done.
call(this);this.__proto__=B.uj.A4;B.uj.A4._Done.call(this);},_ReInit:function(){
B.uj.A4._ReInit.call(this);if(this.L)this.L._ReInit.call(this);},_Mark:function(
E){B.uj.A4._Mark.call(this,E);if(this.L)this.L._Mark(E);},_variants:function(){return B.
un.A4._variants();},L:null,_className:"Device::DeviceClass"};C.Device={_Init:function(
){C.A4._Init.call(this,0);},_variants:function(){return this;},_this:null};
C._Init=function(){C.A4.__proto__=B.uj.A4;};C.Aw=function(E){var A;if((A=C.Device.
_this)&&(A._cycle!=E))A._Done(C.Device._this=null);};return C;})();

/* Embedded Wizard */