/*******************************************************************************
*
* E M B E D D E D   W I Z A R D   P R O J E C T
*
*                                                Copyright (c) TARA Systems GmbH
*                                    written by Paul Banach and Manfred Schweyer
*
********************************************************************************
*
* This file was generated automatically by Embedded Wizard Studio.
*
* Please do not make any modifications of this file! The modifications are lost
* when the file is generated again by Embedded Wizard Studio!
*
* The template of this heading text can be found in the file 'head.ewt' in the
* directory 'Platforms' of your Embedded Wizard installation directory. If you
* wish to adapt this text, please copy the template file 'head.ewt' into your
* project directory and edit the copy only. Please avoid any modifications of
* the original template file!
*
* Version  : 9.30
* Profile  : Browser
* Platform : Tara.WebGL.RGBA8888
*
*******************************************************************************/

var EmWiApp;if(!EmWiApp)throw new Error("The application file '_project.js' isn't yet loaded!"
);if(EmWiApp.um)throw new Error("The unit file 'EnStyle.js' included twice!");EmWiApp.
um=(function(){var B=EmWiApp;var C={};

C.EX={_class:function(){return B.ui.Az;},0:{Data:function(){return B.ur;},Cache:[
],_this:null}};C.EW={_class:function(){return B.ui.Az;},0:{Data:function(){return B.
uq;},Cache:[],_this:null}};
C._Init=function(){};C.Aw=function(E){var A;if((A=C.EX[0]._this)&&(A._cycle!=E))A.
_Done(C.EX[0]._this=null);if((A=C.EW[0]._this)&&(A._cycle!=E))A._Done(C.EW[0]._this=
null);};return C;})();

/* Embedded Wizard */